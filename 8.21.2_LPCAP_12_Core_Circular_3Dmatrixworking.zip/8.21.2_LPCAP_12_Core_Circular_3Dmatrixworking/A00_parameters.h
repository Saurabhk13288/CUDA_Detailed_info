#ifndef A_PARAMETERS_H
#define A_PARAMETERS_H
//##########################################################################################################
//                                         PRE_DEFINED HEADERS
//##########################################################################################################
//Pre built Headers
#include <stdio.h>         // Standard I/O functions like printf, fopen, etc.
#include <string.h>        // For memset, memcpy, etc.
#include <stdlib.h>        // General functions like malloc, exit, etc.
#include <stdint.h>        // For fixed-width integer types (e.g., uint32_t)
#include <stdbool.h>
#include <unistd.h>
#include <signal.h>
#include <sched.h> 
#include <sys/types.h>     // Defines types like u_int, u_char, pid_t
#include <netinet/in.h>    // For sockaddr_in, htons, IPPROTO_UDP, etc.
#include <netinet/ip.h>    // For struct ip
#include <netinet/udp.h>   // For struct udphdr
#include <sys/msg.h>       // For System V message queue
#include <errno.h>         // For error codes (e.g., errno)
#include <pcap.h>          // For libpcap packet capture functions
#include <arpa/inet.h>
#include <sys/stat.h>

#include <sys/socket.h>

#include <sys/time.h>
#include <time.h>
//##########################################################################################################
//                                         USER_DEFINED HEADERS
//##########################################################################################################
//User defined Headers
//#include "A00_file.h"
#include "A01_cleanup.h"           //For Cleanup
#include "A02_cpu_affinity.h"      //
#include "A03_msgq_size.h"         //To update the size of the message queue //TotalSize=2GB,MessageSize=584
#include "A04_fork.h"
#include "A05_lpcap.h"
#include "A06_msgq_rece.h"         //To receive the data from the message queue
#include "A07_msgq_8child.h"
#include "A08_msgq_collector.h"

#include "SP_V1.h"

// #define pragmapack	1
#pragma pack(1)
//##########################################################################################################
//                                         MSG_DEFINED HEADERS
//##########################################################################################################
//Message Queue Parameters
#define MSG_KEY                         0x1470          
#define msg_len                         300000

#define msgqueue_size                   "2147483647"                    //MAX NUMBER OF BYTES IN THE QUEUE
#define msgpacket_size                  "400000"                         //MAX BYTES ALLOWED IN A SINGLE MESSAGE
#define no_queues                       14

//##########################################################################################################
//                                         FILE_WRITE_VALUES
//##########################################################################################################
#define LOG_FLAG					    0
#define DATA_FLAG					    0
#define SCREEN_FLAG					    0              //Screen Flag

#define LPCAP_FLAG					    0
#define MSG_RECE_FLAG				    0
#define MSG_CHILD_FLAG				    0
#define MSG_COLLECTOR_FLAG			    0

//For Data
// #define pulse_index                      91
//#define PULSE_DATA_SIZE1                ((DATA_SIZE)/ (SAMPLE_SIZE * 2)) * PULSE_COUNT              //128 * 64 = 8192 * 1 = 8192  bytes

#define PULSE_DATA_SIZE                 NUM_SAMPLES * SAMPLE_DATA_SIZE * PULSE_COUNT
                                        //   128    *       4          *     64       =   32768
                                        
#define BOARD_PACKET_SIZE               START_HEADER_SIZE + INFO_PACKET_SIZE + NUM_SAMPLES * SAMPLE_DATA_SIZE * BEAM_COUNT + END_FOOTER_SIZE           
                                        //    32          +        64        +    128      *        4         *     8      +       32        = 4224
                                        
#define START_HEADER_SIZE               32                                 // BYTES
#define INFO_PACKET_SIZE                64                                 // BYTES
#define END_FOOTER_SIZE                 32                                 // BYTES

#define NUM_SAMPLES                     128
#define SAMPLE_DATA_SIZE                VALUE_SIZE * VALUE_PER_SAMPLE      // BYTES
#define VALUE_SIZE                      2
#define VALUE_PER_SAMPLE                2

#define PULSE_COUNT                     64
#define BEAM_COUNT                      8
#define CORE_COUNT                      12

#define TARGET                          0

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

//##########################################################################################################
//                              MSGQ_STRUCTURES AND OTHER STRUCTURES
//##########################################################################################################
// Message Queue
struct msgq_char{
    long                                mtype;
    unsigned char                       buffer[msg_len];
};

// struct sp_algo_report{
//                     // int a;
//                     // int b;
//                     // int c;
//                     unsigned int RCout_data[8];
//                     int RCout_size[1];
//                     unsigned int DCout_data[10];            //entered size 10
//                     int DCout_size[1];
//                     unsigned int Dcnt;
//                     unsigned int Ridx_data[10];             //entered size 10
//                     int Ridx_size[1];
//                     unsigned int Peak_aRC[40];
//                     unsigned int Peak_aDP[40];
//                     unsigned int Peak_RC[20];
//                     unsigned int Peak_DP[20];
//                     int CFARdB[20];
//                     unsigned int Zero_DP[20];
//                     int SNR_Out[20];
// };

typedef struct msgHeader
{
	uint8           msgTyp;
	uint8           s_CSCI_ID;
	uint8           D_CSCI_ID;	
	uint8           Ct;	

	uint8           rsvd1;
	uint8           ack;		
	uint16          msgCounter;

	uint16          msgLen;
	uint16          rsvd2;

}msgHeader_t; //12

typedef struct burstMsg
{

	uint16          Burst_id;
	uint16          rsvd2;

	uint32          range;

	uint16          az;
	uint16          el;

}burstMsg_t;  //12

typedef struct stBurstRpt
{
    msgHeader_t     hdr;   //12
    uint8           CSST;
	uint8           NB;
	uint16          rsvd1;
	uint32          rcTime; //4bytes

    burstMsg_t      brst[40];  //12*40 = 480
}stBurstRpt_t;//500 bytes

typedef struct finalstBurstRpt
{
	msgHeader_t                     hdr;   //12
    uint8                           CSST		: 8;
	uint8                           NB		: 8;
	uint16                          rsvd1	: 16;
	uint32                          rcTime; //4bytr

	burstMsg_t                      final_brst[320];  //12*40*8 = 3840
}finalstBurstRpt_t;	//3860 bytes

// finalstBurstRpt_t finalstBurstRpt;

struct my_msgbuf_combine{         //extern struct my_msgbuf_combine msgq_combined;
    long                            mtype;
    stBurstRpt_t                    BurstRpt;
};

struct my_msgbuf_combine_core{         //extern struct my_msgbuf_combine msgq_combined;
    long                            mtype;
    finalstBurstRpt_t               finalstBurstRpt_msgq;
};


//##########################################################################################################
//								    NEW_STRUCTURES_FOR_DATA         18-Aug-2025
//##########################################################################################################
struct info_header{
    uint8_t                             h2[32];                                                // Reserved_Bytes
    uint32_t                            message_count;
    uint16_t                            pri;
    uint16_t                            pw;
    uint32_t                            total_IQ;
    uint8_t                             modulation;
    uint8_t                             ndp;
    uint8_t                             nfp;
    uint8_t                             np;
    uint32_t                            h13;
    uint32_t                            rc_time;
    uint32_t                            pulse_index;
    uint32_t                            h16;
};

struct sample_QI_struct{
    int16_t                             Q_value;
    int16_t                             I_value;
};

union sample_QI_union{
    uint8_t                             char_QI[SAMPLE_DATA_SIZE];
    uint32_t                            int_QI;
    struct      sample_QI_struct        sample_QI_struct_sv; 
};

struct data_4224{
    uint8_t                             start_header[START_HEADER_SIZE];
    struct      info_header             info_header_sv;
    union       sample_QI_union         sample_QI_uv[NUM_SAMPLES][BEAM_COUNT];
    uint8_t                             end_footer[END_FOOTER_SIZE];
};

struct msgq_4224{
	long                                mtype;
	struct      data_4224               data_4224_sv;
};

struct data_4224_64{
    struct      info_header             info_header_sv[BEAM_COUNT];
    union       sample_QI_union         sample_QI_3D_uv[PULSE_COUNT][NUM_SAMPLES][BEAM_COUNT];
};

struct msgq_4224_64{
	long                                mtype;
	struct      data_4224_64            data_4224_64_sv;
};

//##########################################################################################################
//								  END_OF_NEW_STRUCTURES_FOR_DATA         18-Aug-2025
//##########################################################################################################



#endif // PARAMETERS_H
