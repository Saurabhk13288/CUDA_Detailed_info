#include "A00_parameters.h"

extern FILE *board_datafp, *Q_datafp, *I_datafp;
extern FILE *NEWTESTPOINTER;

// extern FILE *lpcap_log, *lpcap_datalog; 
// extern FILE *Msgrcv_log, *Msgrcv_datalog;
//extern int msqid;
extern int msgq_id[no_queues];

//##########################################################################################################
//            CLEANUP FUNCTION CALLED AFTER GETTING SIGNAL FROM SIGNAL HANDLER FUNCTION
//##########################################################################################################
// Cleanup function to close file
void cleanup() {
    //fflush(stdout);
    printf("\n\tShutting Down\n");
    printf("\tAll message queues will now be cleared.\n");
    fflush(stdout);
    for(int i = 0; i < no_queues; i++){
        if (msgctl(msgq_id[i], IPC_RMID, NULL) == -1) {
            perror("msgctl (IPC_RMID) failed");
            exit(EXIT_FAILURE);
        } else {
            printf("\tMSGQ(KEY %04x, ID: %d) deleted.\n",MSG_KEY + i, msgq_id[i]);
            fflush(stdout);
        }
    }

    if (board_datafp) {
        fclose(board_datafp);
        printf("File closed 554456465465.\n");
        board_datafp = NULL;
        printf("File closed fp1.\n");
    }
    

    if (Q_datafp) {
        fclose(Q_datafp);
        Q_datafp = NULL;
        printf("File closed Q_fp.\n");
    }

    if (I_datafp) {
        fclose(I_datafp);
        I_datafp = NULL;
        printf("File closed I_fp.\n");
    }
    
    printf("\tResources cleaned up. Exiting.\n\n");
    exit(EXIT_SUCCESS);
}

//##########################################################################################################
//                                         SIGNAL HANDLER FUNCTIONS
//##########################################################################################################
// Signal handler
void handle_signal(int signum) {
    printf("\n\tCaught signal %d\n", signum);
    // printf("\033[2J\033[H");
    fflush(stdout);
    cleanup();
}

//##########################################################################################################
//                                         SETUP SIGNAL HANDLER FUNCTIONS
//##########################################################################################################
void setup_signal_handlers() {
    struct sigaction sa;
    sa.sa_handler = handle_signal;
    sa.sa_flags = 0;  // You can set additional flags like SA_RESTART or SA_SIGINFO
    sigemptyset(&sa.sa_mask);  // Block no signals during the handler

    // Handle SIGINT (Ctrl+C)
    if (sigaction(SIGINT, &sa, NULL) == -1) {
        perror("sigaction failed for SIGINT");
        exit(EXIT_FAILURE);
    }
    
    // Handle SIGTERM (Termination signal)
    if (sigaction(SIGTERM, &sa, NULL) == -1) {
        perror("sigaction failed for SIGTERM");
        exit(EXIT_FAILURE);
    }

    // Handle SIGQUIT (Quit signal, typically Ctrl+\)
    if (sigaction(SIGQUIT, &sa, NULL) == -1) {
        perror("sigaction failed for SIGQUIT");
        exit(EXIT_FAILURE);
    }
    
    // Handle SIGHUP (Signal sent when terminal is closed)
    if (sigaction(SIGHUP, &sa, NULL) == -1) {
        perror("sigaction failed for SIGHUP");
        exit(EXIT_FAILURE);
    }
}


//##########################################################################################################
//                                         PRINT ON SCREEN
//##########################################################################################################
int width = 76;
void print_hash_line(){
    for (int j = 0; j < 2; j++){
        for (int k = 0; k < width; k++){
            printf("#");
        }
        printf("\n");
    }
}

void print_hash_border(){
    printf("####\t\t\t\t\t\t\t\t\t####\n");
}

void printtop(){    
    print_hash_line();
    print_hash_border();
    print_hash_border();
}
void printend(){
    print_hash_border();
    print_hash_border();
    print_hash_line();   
}

//##########################################################################################################
//                                         FILE AND FOLDER CREATE FUNCTION
//##########################################################################################################
const char *get_file_path(const char *parent_folder, const char *child_folder, const char *filename, const char *extension){
    static char final_path[256];
    static char combined_folder_path[128];

    //  if(mkdir(parent_folder, 0755) != 0 && errno != EEXIST){
    //     perror("Error creating folder or folder already exists.\n");
    //     return NULL;
    // }

    snprintf(combined_folder_path, sizeof(combined_folder_path), "%s/%s", parent_folder, child_folder);
    // printf("Temp: %s\n", combined_folder_path);

    // if(mkdir(combined_folder_path, 0755) != 0 && errno != EEXIST){
    //     perror("Error creating folder or folder already exists.\n");
    //     return NULL;
    // }
    
    time_t current_time;                                                //variable to store time
    struct tm *time_info;                                               //struct to store time
    char time_str[20];                                                  //string to store the time as a string
    time(&current_time);
    time_info = localtime(&current_time);
    strftime(time_str, sizeof(time_str), "%Y_%m_%d_%H:%M:%S", time_info);
    
    snprintf(final_path, sizeof(final_path), "%s/%s_%s.%s", combined_folder_path, filename, time_str, extension);

    return final_path;
}



