void cleanup();
void setup_signal_handlers();
double seconds_since();

void printtop();
void printend();

const char *get_file_path(const char *, const char *, const char *,const char *);