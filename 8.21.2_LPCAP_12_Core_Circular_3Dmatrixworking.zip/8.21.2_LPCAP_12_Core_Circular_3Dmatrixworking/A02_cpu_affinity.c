
#define _GNU_SOURCE
#include "A00_parameters.h"

void set_core(uint32_t core_num){
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);                          // Clear CPU set
    CPU_SET(core_num, &cpuset);                  // Set affinity to CPU 2 (zero-based index)

    // Apply the affinity to the current process
    if (sched_setaffinity(0, sizeof(cpu_set_t), &cpuset) == -1) {
        perror("AFFINITY: sched_setaffinity failed");
        exit(1);
    }
    

    // To verify CPU affinity
    if (sched_getaffinity(0, sizeof(cpu_set_t), &cpuset) == -1) {
        perror("AFFINITY: sched_getaffinity failed");
        exit(1);
    }
    for (int i = 0; i < CPU_SETSIZE; i++) {
        if (CPU_ISSET(i, &cpuset)) {
            //printf("AFFINITY: %d Process assigned to Core %d \n\n", getpid(),i);
        }
    }

}

double seconds_since(struct timespec start, struct timespec end) {
	return (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
}
