#include "A00_parameters.h"

//##########################################################################################################
//                      OPEN THE SYSTEM FILE TO CHANGE THE MESSAGE QUEUE SIZE
//##########################################################################################################
int write_sysctl(const char *path, const char *value) {
    FILE *fptemp = fopen(path, "w");
    if (fptemp == NULL) {
        perror("Error opening sysctl file");
        return -1;
    }
    if (fprintf(fptemp, "%s", value) < 0) {
        perror("Error writing to sysctl file");
        fclose(fptemp);
        return -1;
    }
    fclose(fptemp);
    return 0;
}

//##########################################################################################################
//              UPDATE THE MAX BYTES THE MESSAGE QUEUE CAN HOLD 
//              AND THE MAX SIZE OF A SINGLE MESSAGE IN THE QUEUE
//##########################################################################################################
int change_msq_size(){
    const char *msgmnb_path         =       "/proc/sys/kernel/msgmnb";
    const char *msgmax_path         =       "/proc/sys/kernel/msgmax";

    const char *msgmnb_value        =       msgqueue_size;              //MAX NUMBER OF BYTES IN THE QUEUE
    const char *msgmax_value        =       msgpacket_size;             //MAX BYTES ALLOWED IN A SINGLE MESSAGE

    if (write_sysctl(msgmnb_path, msgmnb_value) != 0) {
        fprintf(stderr, "Failed to update kernel.msgmnb\n");
        return EXIT_FAILURE;
    }

    if (write_sysctl(msgmax_path, msgmax_value) != 0) {
        fprintf(stderr, "Failed to update kernel.msgmax\n");
        return EXIT_FAILURE;
    }
    return 0;
}

int q_creator(int a){
    // int key = MSG_KEY + 1;
    int msqid_dummy = msgget(MSG_KEY + a, IPC_CREAT | 0666); // Dynamic key based on MSG_KEY_MAIN
    if (msqid_dummy == -1) {
        perror("msgget Error (Queue 1-8)");
        return 1;
    }
    //printf("Queue Created %d\n\n", msqid_dummy);
    return msqid_dummy;
}