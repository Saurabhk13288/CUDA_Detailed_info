int write_sysctl(const char * , const char *);
int change_msq_size();
int q_creator();