/*  This main program can be used to create child process
    Total proccess created is given by the formula 2^N
    Total child proccess created is given by the formula 2^N-1
    N is the number of times the fork command is used.
    
    Fork has been used 4 times in this process, 
    so a total of 16 process are created.
    15 child are created, and 1 is the main process already running.
    n1, n2, n3, n4 are used as binary counters (for understanding)

    0000 - Child 1
    0001 - Child 2
    |   |   |   |
    |   |   |   |   
    1110 - Child 15
    ===============
    1111 - Main process

    Note: Child are not created in this order
    For understanding, we are using this numbering,
    Actual hierarchy is different and is not currently required. (^_^)
*/
#include "A00_parameters.h"
uint8_t n1, n2, n3, n4;
uint32_t slptime = 0;
uint8_t intital_core = 0;

extern FILE *NEWTESTPOINTER;

void printID(){
        // // printf("%d %d %d %d %d\n",checkPID(),n1, n2, n3, n4);
        // usleep(checkPID()*100000);
        // printf("%02d ParentID: %07d\tMyId: %07d\n\n",checkPID(), getppid(), getpid());
        // fflush(stdout);
        // // printf("MyId: %d\n\n", getpid());
}

int checkPID(){
    bool new1 = n1;
    bool new2 = n2;
    bool new3 = n3;
    bool new4 = n4;

    return new1 * 8 + new2 * 4 + new3 * 2 + new4 * 1;
}

void process_creator(){
    n2 = fork();
    n1 = fork();
    n3 = fork();
    n4 = fork();
    
    
    if (checkPID() == 1){
        // sleep (slptime + 1);
        printID();
        set_core(intital_core + 2);                                 //A02_cpu_affinity.c
        checkPID();
        //while(1);
        msg_8child(1);
    }

    else if (checkPID() == 2){
        // sleep (slptime + 2);
        printID();
        set_core(intital_core + 3);
        checkPID();
        //while(1);
        msg_8child(2);
    }

    else if (checkPID() == 3){
        // sleep (slptime + 3);
        printID();
        set_core(intital_core + 4);
        checkPID();
        //while(1);
        msg_8child(3);
    }

    else if (checkPID() == 4){
        // sleep (slptime + 4);
        printID();
        set_core(intital_core + 5);
        checkPID();
        //while(1);
        msg_8child(4);
    }

    else if (checkPID() == 5){
        // sleep (slptime + 5);
        printID();
        set_core(intital_core + 6);
        checkPID();
        //while(1);
        msg_8child(5);
    }

    else if (checkPID() == 6){
        // sleep (slptime + 6);
        printID();
        set_core(intital_core + 7);
        checkPID();
        //while(1);
        msg_8child(6);
    }

    else if (checkPID() == 7){
        // sleep (slptime + 7);
        printID();
        set_core(intital_core + 8);
        checkPID();
        //while(1);
        msg_8child(7);    
    }

    else if (checkPID() == 8){
        // sleep (slptime + 8);
        printID();
        set_core(intital_core + 9);
        checkPID();
        //while(1);
        msg_8child(8);
        //q_creator(8);
    }  

    else if (checkPID() == 9){
        //sleep (slptime + 9);
        printID();
        set_core(intital_core + 10);
        checkPID();
        //while(1);
        msg_8child(9);
        
    }

    else if (checkPID() == 10){
        // sleep (slptime + 10);
        printID();
        set_core(intital_core + 1);
        checkPID();
        sleep(2);
        // while(1);
        msg_8child(10);
        
    }

    else if (checkPID() == 11){
        // sleep (slptime + 10);
        printID();
        set_core(intital_core + 11);
        checkPID();
        sleep(2);
        // while(1);
        msg_8child(11);                               
    }

    else if (checkPID() == 12){
        // sleep (slptime + 10);
        printID();
        set_core(intital_core + 12);
        checkPID();
        sleep(2);
        // while(1);
        msg_8child(12);                  
    }

    else if (checkPID() == 13){
        // sleep (slptime + 10);
        printID();
        set_core(intital_core + 13);
        checkPID();
        sleep(2);
        // while(1);
        queue_extractor();                              //A06_msgq_rece.c               
    }

    else if (checkPID() == 14){
        // sleep (slptime + 10);
        printID();
        set_core(intital_core + 14);
        checkPID();
        sleep(2);
        // while(1);
        msgq_collector();             
    }
    
    else if (checkPID() == 15){
        // sleep (slptime + 11);
        printID();
        // set_core(intital_core + 0);
        checkPID();
        // sleep(4);
        // file_write();
        setup_signal_handlers();                        //A01_cleanup.c Register signals
        //while(1);
        sleep(5);
        A_lpcap();                                      //A05_lpcap.c
    }
    //Add more conditions for creating more child process.
}

    
