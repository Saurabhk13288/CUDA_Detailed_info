#include "A00_parameters.h"
//##########################################################################################################
//                                         LPCAP STRUCTURES - DO NOT CHANGE
//##########################################################################################################

// 14 Bytes
struct eth_header {
    unsigned char dest_mac[6];
    unsigned char src_mac[6];
    unsigned short eth_type;
};
//20 bytes
struct ip_header {
    unsigned char ver_ihl;       // Version (4 bits) + IHL (4 bits)
    unsigned char tos;           // Type of service
    unsigned short tot_len;      // Total length
    unsigned short id;           // Identification
    unsigned short frag_off;     // Flags + Fragment offset
    unsigned char ttl;           // Time to live
    unsigned char protocol;      // Protocol (TCP=6, UDP=17, ICMP=1)
    unsigned short check;        // Header checksum
    unsigned int saddr;          // Source IP address
    unsigned int daddr;          // Destination IP address
};
//8 bytes
struct udp_header 
{
    unsigned short source_port;
    unsigned short dest_port;
    unsigned short len;
    unsigned short check;
};

struct header_read1{
    // int start_bytes[8];					//change to char to get value for each byte
    int h2[8];							//Reserved_Bytes
    int message_count;
    short int PRI;
    short int PW;
    int total_IQ;
    unsigned char modulation;
    unsigned char NDP;
    unsigned char NFP;
    unsigned char NP;
    int h13;
    int RC_time;
    int pulse_idx;
    int h16;
}info_header_s_v1;
//##########################################################################################################
//                                     LPCAP DEVICE SELECTION
//##########################################################################################################
//Check device name on host system using the ifconfig command.
//and update the "*dev" parameter to NIC card name
char errbuf[PCAP_ERRBUF_SIZE];
pcap_t *handle;
char *dev_10G                                       =           "enp6s0f2";
pcap_if_t *selected_dev                             =           NULL;
pcap_if_t *alldevs, *dev_var;
//##########################################################################################################
//                                     MSGQ_PARAMETERS
//##########################################################################################################
extern struct msgq_char msgq_struct;
extern int msgq_id[no_queues];


unsigned int old_msg_count = 0;
int count, total_count;
unsigned int old_pulse_idx = 0;;
//##########################################################################################################
//                                      TIME_PARAMETERS       
//##########################################################################################################
struct timespec start1, end1;
//##########################################################################################################
//                                 LPCAP_LOG_FILE_PARAMETERS
//##########################################################################################################
FILE *lpcap_log, *lpcap_datalog;
//##########################################################################################################
//                                      OTHER PARAMETERS
//##########################################################################################################
//int count                                         =           0;
unsigned char lpcap_data_buff[5000];
int recboard_incorrect_packet                       =           0;
int recboard_correct_packet                         =           0;
int incorrect_length                                =           0;
int newtime                                         =           0;
//##########################################################################################################
//const struct pcap_pkthdr *header;
int stopper = 0;
//##########################################################################################################
//                               LPCAP PACKET HANDLER FUNCTION
//##########################################################################################################
void packet_handler(unsigned char *user, const struct pcap_pkthdr *header, const unsigned char *packet) {
    
    //FILE *fp = (FILE *)user;
    (void)user;
    // (void)header;
    struct timeval ts                              =           header->ts;
    char time_str1[64];
    time_t raw_time                                =           ts.tv_sec;
    struct tm *ltime                               =           localtime(&raw_time);
    strftime(time_str1, sizeof(time_str1), "%H:%M:%S",ltime);
    
    #if LOG_FLAG * LPCAP_FLAG
        fprintf(lpcap_log,"%s.%.06ld,%u,%u\n",time_str1, (long) ts.tv_usec, header->caplen, header->len);
        fflush(lpcap_log);
    #endif

    //ADD a file write here, to capture each packet sent from the board.
    //Currently we will discard all the packets 
    //which are not equal to the expected packet size i.e. 4224

    //printf("Packed at: %s.%.06ld, Capt. %u Bytes, Actual %u Bytes\n", 
    //time_str1, (long) ts.tv_usec, header->caplen, header->len);
//##########################################################################################################
    struct ip_header *ip                            =           (struct ip_header *)(packet + 14);
    int ip_header_len                               =           (ip->ver_ihl & 0x0F) * 4;                       //IHL field gives header length in 32-bit words
    struct udp_header *udp                          =           (struct udp_header *)(packet + 14 + ip_header_len);
    int udp_header_len                              =           sizeof(struct udphdr);    
    int payload_offset                              =           14 + ip_header_len + udp_header_len;
    int payload_len                                 =           ntohs(udp->len) - udp_header_len;
//##########################################################################################################
    msgq_struct.mtype = 1;   

#if DATA_FLAG * LPCAP_FLAG
    memcpy(lpcap_data_buff, packet, (payload_len + payload_offset));

    fwrite(lpcap_data_buff, 1, (payload_len + payload_offset), lpcap_datalog);
    fflush(lpcap_datalog);
#endif
    //Message queue
    if(payload_len == BOARD_PACKET_SIZE){
        memcpy(msgq_struct.buffer, packet + payload_offset, payload_len); 
    //  	memcpy(&info_header_s_v1, msgq_struct.buffer + 32, INFO_PACKET_SIZE);        
    // //   old_msg_count = ntohl(info_header_s_v1.message_count);
    //         if(old_msg_count == ntohl(info_header_s_v1.message_count)){
    //             count++;
    //             old_pulse_idx = ntohl(info_header_s_v1.pulse_idx);
    //         }
    //         else{
    //             total_count = count;
    //             printf("total_count = %d , msg_count: %u, PULSE_IDX:%u\n", total_count, ntohl(info_header_s_v1.message_count), old_pulse_idx);
    //             count = 1;
    //         }
    //     old_msg_count = ntohl(info_header_s_v1.message_count);	
	   // printf(" Msgcn: %u\n",ntohl(info_header_s_v1.message_count));
      //  oldtime1 = 	ntohl(info_header_s_v1.RC_time);
        if(msgsnd(msgq_id[0], &msgq_struct, payload_len, 0) == -1){
            if(errno != EAGAIN){
                perror("LPCAP: Msg send error\n");
            }
        }
        else{
           // printf("payload forwarded (%d bytes)\n\n",payload_len);
            recboard_correct_packet++;
            incorrect_length                        =           0;
        }
    }
    else {
        incorrect_length                            =           payload_len;
        printf("LPCAP: Msg discarded size: %d\n",payload_len);
        recboard_incorrect_packet++;
    }
    // if (stopper == (128*100)){
    //     while(1);
    // }
    // stopper++;
    //printf("LPCAP: ValidPack %d, InValidPack: %d, IncorrectBytes: %d\n", recboard_correct_packet, recboard_incorrect_packet, incorrect_length);    
}
//##########################################################################################################
//                              end of lpcap handler function
//##########################################################################################################
//##########################################################################################################
//           LPCAP FUNCTION - CALLED IN THE MAIN PROCESS -- [checkPID()== 15] IN A04_FORK FILE
//##########################################################################################################
int A_lpcap(){
    //##########################################################################################################
    //                                       TIME_LOG
    //##########################################################################################################
    time_t current_time;
    struct tm *time_info;
    struct timeval ts;
    char time_str[100];
    time(&current_time);
    time_info = localtime(&current_time);
    gettimeofday(&ts, NULL);
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);

    printf("LPCAP PROCESS STARTED: %s.%06ld\n", 
            time_str, ts.tv_usec);
    //##########################################################################################################
    //                                 LPCAP LOG Creation
    //##########################################################################################################
    #if LOG_FLAG * LPCAP_FLAG
        const char *lpcap_path = get_file_path("LOG_FILES","LPCAP_LOG","A05_lpcap","txt");
        if(lpcap_path == NULL){
            return 1;  
        }
        lpcap_log = fopen(lpcap_path,"wb");
        if (lpcap_log == NULL){
            perror("LPCAP: Unable to open lpcap_log file.\n");
        }
    #endif

    #if DATA_FLAG * LPCAP_FLAG
        const char *lpcap_data_path = get_file_path("DATA_FILES","LPCAP_DATA","A05_lpcap","bin");
        if(lpcap_data_path == NULL){
            return 1;
        }
        lpcap_datalog = fopen(lpcap_data_path,"wb");
        if (lpcap_datalog == NULL){
            perror("LPCAP: Unable to open lpcap_datalog file.\n");
        }
    #endif

    // const char *path = get_file_path("LOG_FILES","LPCAP_LOG","A05_lpcap","txt");
    // if(path == NULL){
    //     return 1;
    // }

    // lpcap_log = fopen(path,"wb");
    // if (lpcap_log == NULL){
    //     perror("LPCAP: Unable to open log file.\n");
    // }
    #if LOG_FLAG * LPCAP_FLAG
        fprintf(lpcap_log,"LPCAP PROCESS STARTED: %s.%06ld\n", 
                time_str, ts.tv_usec);
        fflush(lpcap_log);
    #endif
    //##########################################################################################################
    //                                    LPCAP DEVICE FIND STARTS
    //##########################################################################################################
    if (pcap_findalldevs(&alldevs, errbuf) == -1) {
        #if LOG_FLAG * LPCAP_FLAG
            fprintf(lpcap_log, "LPCAP: Error finding devices: %s\n",errbuf);
            fflush(lpcap_log);
            return 1;
        #endif
    }
    if (alldevs == NULL) {
        #if LOG_FLAG * LPCAP_FLAG
            fprintf(lpcap_log, "LPCAP: No devices found\n");
            fflush(lpcap_log);
            return 1;
        #endif
    }
    //for checking which devices connected
    //printf("LPCAP: Trying to connect to %s:\n", dev_10G);
    for (dev_var = alldevs; dev_var != NULL; dev_var = dev_var->next) {
        if(strcmp(dev_var->name,dev_10G) == 0){
            selected_dev = dev_var;
            break;
        }
    }
    //selected_dev                                =           dev_10G;                              //delete
    //printf("LPCAP: Using device: %s\n", selected_dev->name);
    #if LOG_FLAG * LPCAP_FLAG    
        fprintf(lpcap_log, "LPCAP: Using device: %s\n", selected_dev->name);
        fflush(lpcap_log);
    #endif
    //##########################################################################################################
    //                                      LPCAP CONNECTION ESTABLISHMENT
    //##########################################################################################################
    // Step 2: Open the device for live capture
    handle = pcap_open_live(selected_dev->name, msg_len, 0, 10, errbuf);
    if (handle == NULL) {      
        #if LOG_FLAG * LPCAP_FLAG
            fprintf(lpcap_log, "LPCAP: Couldn't open device %s: %s\n", selected_dev->name, errbuf);
            fflush(lpcap_log);
            return 1;
        #endif
    }
    //printf("LPCAP: Device connected %s\n",selected_dev->name);
    struct bpf_program fp;

    char filter_exp[]                           =           "udp port 11112";  // change to "port 11112" to match your port
    bpf_u_int32 net;
//##########################################################################################################
    bpf_u_int32 mask;  // To store network mask
    while (pcap_lookupnet(selected_dev->name, &net, &mask, errbuf) == -1) {
            time(&current_time);
            time_info = localtime(&current_time);
            gettimeofday(&ts, NULL);
            strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);

            #if LOG_FLAG * LPCAP_FLAG
                fprintf(lpcap_log, "LPCAP: Couldn't get %s: \n%s Time: %s.%06ld\n", 
                                    selected_dev->name, errbuf, time_str, ts.tv_usec);
            #endif
                fflush(lpcap_log);

            for(int i = 5; i > 0; i--){
            //printf("\033[2J\033[H");                      //Clear Screen and move cursor to top - left
            //printtop();
            //printf("\nPlease check the RACSID board connection \n");
            //printf("\nRetrying to connect in %d sec.. \n",i);
            //printend();          
            sleep(1);
        }
        net                                     =           0;   // fallback if fails
        mask                                    =           0;
        // fflush(stdout);
    }
    // struct in_addr net_addr, mask_addr;
    // net_addr.s_addr = net;
    // mask_addr.s_addr = mask;
    // printf("Network address: %s\n", inet_ntoa(net_addr));
    // printf("Netmask: %s\n", inet_ntoa(mask_addr));
//##########################################################################################################
    if (pcap_compile(handle, &fp,filter_exp, 0, net) == -1) {
        #if LOG_FLAG * LPCAP_FLAG
            fprintf(lpcap_log, "LPCAP: Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
            return 1;
        #endif
    }
    if (pcap_setfilter(handle, &fp) == -1) {
        #if LOG_FLAG * LPCAP_FLAG
            fprintf(lpcap_log, "LPCAP: Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
            return 1;
        #endif
    }
//##########################################################################################################
    time(&current_time);
    time_info = localtime(&current_time);
    gettimeofday(&ts, NULL);
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);
    #if LOG_FLAG * LPCAP_FLAG
        fprintf(lpcap_log, "LPCAP: Connection Established %s: Time: %s.%06ld\n", 
                                    selected_dev->name, time_str, ts.tv_usec);
        fflush(lpcap_log);
    #endif

    //printf("LPCAP: Connection Established with RACSID board\nReady for packet capture\nPress Ctrl+C to stop...\n");        
//##########################################################################################################    
//##########################################################################################################
    // Step 4: Start capture loop
    // printf("\033[2J\033[H");
    // printtop();
    // printend();
    #if LOG_FLAG * LPCAP_FLAG
        fprintf(lpcap_log,"Receive_Time::,Captured Bytes::,Actual Bytes::\n");
        fflush(lpcap_log);
    #endif
    pcap_loop(handle, -1,packet_handler, NULL);
    //##########################################################################################################
    /*
    int pcap_loop(pcap_t *p, int cnt, pcap_handler callback, u_char *user);
    Parameters:
    pcap_t *p	Pointer to the pcap handlze (opened by pcap_open_live() or pcap_open_offline()).
    int cnt	Number of packets to capture before returning.
        - If cnt > 0: capture exactly cnt packets, then stop.
        - If cnt = 0: capture indefinitely until error or break.
        - If cnt < 0 (usually -1): capture indefinitely (same as 0).
    pcap_handler callback	Pointer to a callback function that will be called for every captured packet.
    u_char *user	A user-defined pointer passed to the callback function (can be NULL if not used).
    */
//##########################################################################################################
    pcap_freealldevs(alldevs);
    pcap_close(handle);
    return 1;
}
