#include "A00_parameters.h"

void print_info(struct info_header info_header_sv, uint32_t counter);
//##########################################################################################################
//                                     FILE PARAMETERS
//##########################################################################################################
FILE    *board_datafp, *Q_datafp,          *I_datafp; 
FILE    *msgrcv_log,   *NDP_data;
FILE    *Msgrcv_log,   *Msgrcv_datalog,    *Matrix_datalog;
//##########################################################################################################
//                                     MSGQ_PARAMETERS
//##########################################################################################################
extern          int             msgq_id[no_queues];
extern struct   msgq_4224       msgq_4224_sv;               //Receive 4224      bytes   32+64+4096+32
extern struct   msgq_4224_64    msgq_4224_64_sv;            //Receive 262656    bytes   (64    +   4096)*8 
//##########################################################################################################
//                                     TIME_PARAMETERS
//##########################################################################################################
struct          timespec        start2, end2;
//##########################################################################################################
//                                     DATA_PARAMETERS
//##########################################################################################################
uint8_t beg_header                    =       0x5a;                //Start Header
uint8_t end_header                    =       0xa5;                //End Header
//##########################################################################################################
//                                     QUEUE_EXTRACTOR_FUNCTION
//##########################################################################################################
void queue_extractor(){
    //##########################################################################################################
    //                                 MESSAGE_QUEUE/ID_CREATION
    //##########################################################################################################
    msgq_4224_64_sv.mtype                       =            1;
    //##########################################################################################################
    //                                 FILE_CREATION
    //##########################################################################################################
    #if LOG_FLAG * MSG_RECE_FLAG
        const char *msgrcvpath = get_file_path("LOG_FILES","MSG_RCV_LOG","A06_msg_rece","txt");
        if(msgrcvpath == NULL){
            exit(1);
        }
        Msgrcv_log = fopen(msgrcvpath,"wb");
        if (Msgrcv_log == NULL){
            perror("RECE: Unable to open Msgrcv_log file.\n");
        }
        //printf("FILE.h Msgrcv_datalog = %p\n", Msgrcv_log);
    #endif

    #if DATA_FLAG * MSG_RECE_FLAG
        const char *msgrcv_data_path = get_file_path("DATA_FILES","MSG_RCV_DATA","A06_msg_rece","bin");
        if(msgrcv_data_path == NULL){
            exit(1);
        }
        Msgrcv_datalog = fopen(msgrcv_data_path,"wb");
        if (Msgrcv_datalog == NULL){
            perror("RECE: Unable to open Msgrcv_datalog file.\n");
        }


        const char *matrix_data_path = get_file_path("DATA_FILES","MSG_RCV_DATA","matrix_Datalog","bin");
        if(matrix_data_path == NULL){
            exit(1);
        }
        Matrix_datalog = fopen(matrix_data_path,"wb");
        if (Matrix_datalog == NULL){
            perror("RECE: Unable to open Msgrcv_datalog file.\n");
        }   
    #endif
    // const char *path = get_file_path("DATA_FILE", "BOARD_DATA_4224", "00_board_datafp", "bin");
    // if(path == NULL){
    //     exit(1);
    // }
    // board_datafp = fopen(path,"wb");
    // if(board_datafp == NULL){
    //     printf("RECE: file not open 00_board_datafp.bin\n");
    // }
    // path = get_file_path("DATA_FILE", "QI_8192_DATA", "00_data_QI", "bin");
    // if(path == NULL){
    //     exit(1);
    // }
    // Q_datafp = fopen(path,"wb");
    // if(Q_datafp == NULL){
    //     printf("RECE: file not open data_Q.bin\n");
    // }
    // path = get_file_path("DATA_FILE", "NDP_DATA", "00_data_NDP", "bin");
    // if(path == NULL){
    //     exit(1);
    // }
    // NDP_data = fopen(path,"wb");
    // if(NDP_data == NULL){
    //     printf("RECE: file not open data_Q.bin\n");
    // }
    // I_datafp = fopen("00_data_I.bin","wb");
    // if(I_datafp == NULL){
    //     printf("RECE: file not open data_I.bin\n");
    // }
    //##########################################################################################################
    //                                 MSG_RCV Data_log Creation 
    //##########################################################################################################
    // path = get_file_path("Log_Files", "MSG_RCV_LOG", "MSG_RCV_logfile", "bin");
    // if(path == NULL){
    //     exit(1);
    // }
    // msgrcv_log = fopen(path,"wb");
    // if (msgrcv_log == NULL){
    //     perror("RECE: Unable to open log file.\n");
    // }
    #if LOG_FLAG * MSG_RECE_FLAG
        fprintf(Msgrcv_log,"Receive_Time::, Captured Bytes::\n");
        fflush(Msgrcv_log);
    #endif
    //##########################################################################################################
    //                                 EXTRACTION PARAMETERS
    //##########################################################################################################
    printf("RECE: Waiting for messages...\n");
    //printf("MAGQRECE.h Msgrcv_datalog = %p\n", Msgrcv_log);
    uint32_t valid_packet                        =       0;                                  // Initial message count
    uint32_t temp_valid_packet                   =       0;                                  // 10 Jul
    uint32_t invalid_packet                      =       0;
    uint32_t counter                             =       0;
    uint32_t while_loop_counter                  =       0;
    uint32_t valid_dwell_counter                 =       0;
    // uint32_t temp_valid_dwell_counter            =       0;
    uint32_t invalid_dwell_counter               =       0;
    bool temp_invalid_dwell_counter              =       0;
    uint32_t i                                   =       0;
    printf("RECE: MSGRECE working.\n");
    // Loop to receive messages
    uint32_t core_loop_counter = 0;
    //##########################################################################################################
    //                                 WHILE LOOP RECEIVING STARTS 
    //##########################################################################################################
    uint32_t    A06_rece_counter    =   0;
    
    while (1) {
        //##########################################################################################################
        //                                 PRINT FOR SCREEN
        //##########################################################################################################
        // if (while_loop_counter %64 == 0 && temp == 1){
        //     // printf("\033[2J\033[H");                //Clear Screen and move cursor to top - left
        //     // printtop();
        //     // printf("####\t Valid Dwell  : %012d,\tInValid Dwell  : %04d\t\t####\n", valid_dwell_counter, invalid_dwell_counter);
        //     // printf("####\t Valid Packet :\t\t  %02d,\tInvalid Packet : %04d\t\t####\n", temp_valid_packet, invalid_pack);
        //     // printend();
        //     #if SCREEN_FLAG * MSG_RECE_FLAG
        //         printf("Valid Dwell  : %05d, InValid Dwell  : %04d####\n", valid_dwell_counter, invalid_dwell_counter);
        //         printf("Valid Packet : %02d, Invalid Packet : %04d####\n", temp_valid_packet, invalid_packet);    
        //     #endif
        // }
        // // temp = 1; 
        #if SCREEN_FLAG * MSG_RECE_FLAG
            printf("\033[2J\033[H");                //Clear Screen and move cursor to top - left
            printf("While: %010u, Val Dwell  : %08u, InVal Dwell  : %04u\n",
                    while_loop_counter, valid_dwell_counter, invalid_dwell_counter);
            printf("While: %010u, CurVal Pack: %05u ValP(InvalDwell) : %04u, Inval Packet : %04d\n",
                    while_loop_counter, temp_valid_packet, valid_packet, invalid_packet);
            printf("While: %010u, Pac Countr : %05u, Code Counter : %04u****\n\n",
                    while_loop_counter, ntohl(msgq_4224_sv.data_4224_sv.info_header_sv.pulse_index), counter);
            if(invalid_dwell_counter > 1){
                while(1);
            }
        #endif
        //##########################################################################################################
        //                          DATA_RECIEVE FROM LPCAP HAPPENS HERE
        //##########################################################################################################
        //RollBack value to 0 after hitting 64
        counter                             %=      PULSE_COUNT;
        temp_valid_packet                   %=      PULSE_COUNT;
        ssize_t msg_size = msgrcv(msgq_id[0], &msgq_4224_sv, sizeof(msgq_4224_sv.data_4224_sv), 1 , 0);
        if (msg_size == -1) {
            perror("RECE: msgrcv");
            exit(1);
        }
        //##########################################################################################################
        ///10/07/2025
        time_t current_time;
        struct tm *time_info;
        struct timeval ts;
        char time_str[100];
        time(&current_time);
        time_info = localtime(&current_time);
        gettimeofday(&ts, NULL);
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);
        // fprintf(msgrcv_log,"Receive_Time::, Captured Bytes::\n");
        // fflush(msgrcv_log);
        //printf("RECE: msg_rcv data %ld\n",msg_size);
        #if LOG_FLAG * MSG_RECE_FLAG
            fprintf(Msgrcv_log,"%s.%.06ld,%ld\n", time_str, (long) ts.tv_usec, msg_size);
            fflush(Msgrcv_log);
        #endif
        //##########################################################################################################
        ++counter;
        ++while_loop_counter;
        //##########################################################################################################
        //                            WRITE ALL RECEIVED DATA IN FILE
        //##########################################################################################################
        // memcpy(data_buff, &msgq_4224_sv.data_4224_sv, msg_size);
        #if DATA_FLAG * MSG_RECE_FLAG
            fwrite(data_buff, 1, msg_size, Msgrcv_datalog);
            fflush(Msgrcv_datalog);
        #endif
        //##########################################################################################################
        //                       MATCH PACKETSIZE -> HEADER -> FOOTER AND RAISE FLAG
        //##########################################################################################################
        // clock_gettime(CLOCK_MONOTONIC, &start);
        if(msg_size == BOARD_PACKET_SIZE ){
            uint32_t flag = 1;
            //Check the data packet if start and header is matched.
            for(i = 0; i < START_HEADER_SIZE ;i++){
                if(msgq_4224_sv.data_4224_sv.start_header[i] != beg_header){
                    flag = 0;
                    break;
                }
            }
            //To check last header, only if start header is matched
            if(flag){
                for(i = 0; i < END_FOOTER_SIZE ;i++){
                    if(msgq_4224_sv.data_4224_sv.end_footer[i] != end_header){
                        flag = 0;
                        break;
                    }
                }
            }
            //##########################################################################################################
            //                                   START MATCHING THE PULSE COUNTER
            //                          Expects first count as "1" till PULSE_COUNT
            //##########################################################################################################
            if (flag){
                //Reset the counter when 1 is received in the pulse_index in header
                if(ntohl(msgq_4224_sv.data_4224_sv.info_header_sv.pulse_index) == 1){
                    counter = ntohl(msgq_4224_sv.data_4224_sv.info_header_sv.pulse_index);
                    if (temp_valid_packet != 64)
                    {
                        valid_packet += temp_valid_packet;
                    }
                    temp_valid_packet = 0;
                    invalid_dwell_counter += temp_invalid_dwell_counter;
                }
                if (ntohl(msgq_4224_sv.data_4224_sv.info_header_sv.pulse_index) == counter){
                    ++temp_valid_packet;
                    
                    memcpy(msgq_4224_64_sv.data_4224_64_sv.sample_QI_3D_uv + (counter - 1), &msgq_4224_sv.data_4224_sv.sample_QI_uv, sizeof(msgq_4224_sv.data_4224_sv.sample_QI_uv));

                }   //End of if statement for Pulse Count          //Checks the Pulse count inside packet everytime
                else{
                    ++invalid_packet;
                    temp_invalid_dwell_counter                  =       1;
                    //printf("RECE: Inside: Valid:%d, Invalid %d\n", temp_valid_packet, invalid_packet);
                    continue;
                }
            }   //End of checking of a single packet
        //##########################################################################################################
            if(temp_valid_packet == PULSE_COUNT){            
                temp_invalid_dwell_counter                      =       0;
                for (int beam_loop = 0; beam_loop < BEAM_COUNT; beam_loop++){
                    memcpy(&msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop], &msgq_4224_sv.data_4224_sv.info_header_sv, sizeof(msgq_4224_sv.data_4224_sv.info_header_sv));
                }
                #if DATA_FLAG * MSG_RECE_FLAG
                    fwrite(AllData_2d + beam_loop, 1, (INFO_PACKET_SIZE + PULSE_DATA_SIZE) * BEAM_COUNT, Matrix_datalog);
                    fflush(Matrix_datalog);
                #endif
                core_loop_counter = valid_dwell_counter%12;
                if(msgsnd(msgq_id[core_loop_counter + 1], &msgq_4224_64_sv, sizeof(msgq_4224_64_sv.data_4224_64_sv), 0) == -1){
                    if(errno != EAGAIN){
                        perror("RECE: Msg send error\n");
                    }        
                }
                valid_dwell_counter++;
            }
        //##########################################################################################################
        }   //End of if statement
        
    }   //End of while loop
        printf("RECE: [receiver] Finished writing data to file.\n");

}//End of queue_extractor function
