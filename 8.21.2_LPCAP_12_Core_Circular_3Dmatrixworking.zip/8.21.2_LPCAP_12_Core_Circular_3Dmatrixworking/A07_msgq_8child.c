#include "A00_parameters.h"
#define CHUNK_SIZE                                  300000                   // Size of each message

void print_info(struct info_header info_header_sv, uint32_t counter);

//##########################################################################################################
//                                SP ALGO PARAMETERS
//##########################################################################################################
const int idata[8192]                   =           {0};
const int qdata[8192]                   =           {0};
unsigned int np                         =            64;
unsigned int fsz                        =           128;
unsigned int RCout_data[8]              =           {0};
int RCout_size[1]                       =           {0};
unsigned int DCout_data[8]              =           {0};
int DCout_size[1]                       =           {0};
unsigned int Dcnt                       =            0;              
unsigned int Ridx_data[]                =           {0};
int Ridx_size[1]                        =           {0};
unsigned int Peak_aRC[40]               =           {0};
unsigned int Peak_aDP[40]               =           {0};
unsigned int Peak_RC[20]                =           {0};
unsigned int Peak_DP[20]                =           {0};
int CFARdB[20]                          =           {0};
unsigned int Zero_DP[20]                =           {0};
int SNR_Out[20]                         =           {0};
//##########################################################################################################
//                                  OTHER_PARAMETERS
//##########################################################################################################
unsigned char childdata_buff[BEAM_COUNT][PULSE_DATA_SIZE];

// char filename[100];
char Qnewfilename[100];
char Inewfilename[100];
char IQnewfilename[100];
struct timespec start, end;
//##########################################################################################################
//                                  MSGQ_PARAMETERS
//##########################################################################################################
extern int msgq_id[no_queues];                                              //IDs for the all the queues
extern struct msgq_char msgq_struct;
extern struct sp_algo_report algo_data;

extern struct   msgq_4224_64    msgq_4224_64_sv;

uint32_t oldtime;
//##########################################################################################################
FILE *Msgrcv8child_log, *Msgrcv8child_datalog, *QI_datalog;
//##########################################################################################################

//##########################################################################################################
//               EXTARCT THE DATA FROM THE COLLECTOR MESSAGE BASED ON BEAM ORDER
//##########################################################################################################
// int Q_buff_8192[PULSE_DATA_SIZE / 4];
// int I_buff_8192[PULSE_DATA_SIZE / 4];
short int Q_buff_8192[BEAM_COUNT][PULSE_DATA_SIZE / 4];
short int I_buff_8192[BEAM_COUNT][PULSE_DATA_SIZE / 4];

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

//##########################################################################################################
// extern struct my_msgbuf_combine msgq_combined;
struct my_msgbuf_combine_core my_msgbuf_combine_core_sv;
// extern unBurst_t stBrtRpt;
// unBurst_t stBrtRpt;
// stBurstRpt_t BurstRpt;                  //Ankush 12Aug
// extern stBurstRpt_t BurstRpt;
finalstBurstRpt_t finalstBurstRpt;
//##########################################################################################################
void msg_8child(int i){
    usleep( i * 1000);
    // struct header_read info_header_s_v;
    my_msgbuf_combine_core_sv.mtype                 =           i;  
    //##########################################################################################################
    //                      OPEN A FILE TO WRITE EVERTHING IN THE FILE
    //##########################################################################################################

    // FILE *IQnewfilepointer;
    // sprintf(IQnewfilename, "MOHAN/IQ%d_BeamINTfile.bin", i);
    // IQnewfilepointer = fopen(IQnewfilename, "wb");
    // if (IQnewfilepointer == NULL) {
    //     perror("CHILD: Error opening output file");
    //     fclose(IQnewfilepointer);
    //     exit(1);
    // }

    //##########################################################################################################
    //                                 MSG_RCV8child Data_log Creation 
    //##########################################################################################################
    #if LOG_FLAG * MSG_CHILD_FLAG
        const char *msgrcv_childlog_path = get_file_path("LOG_FILES","MSG_RCV_CHILD_LOG","A07_msg_rece_child","txt");
        if(msgrcv_childlog_path == NULL){
            exit(1);
        }
        Msgrcv8child_log = fopen(msgrcv_childlog_path,"wb");
        if (Msgrcv8child_log == NULL){
            perror("CHILD:Unable to open Msgrcv_log file.\n");
        }
    #endif

    #if DATA_FLAG * MSG_CHILD_FLAG
        const char *msgrcv_childdata_path = get_file_path("DATA_FILES","MSG_RCV_CHILD_DATA","A07_msg_rece_child","bin");
        if(msgrcv_childdata_path == NULL){
            exit(1);
        }
        Msgrcv8child_datalog = fopen(msgrcv_childdata_path,"wb");
        if (Msgrcv8child_datalog == NULL){
            perror("CHILD:Unable to open Msgrcv_datalog file.\n");
        }    

        const char *QI_path = get_file_path("DATA_FILES","MSG_RCV_CHILD_DATA","QI_data","bin");
        if(QI_path == NULL){
            exit(1);
        }
        QI_datalog = fopen(QI_path,"wb");
        if (QI_datalog == NULL){
            perror("CHILD:Unable to open Msgrcv_datalog file.\n");
        } 
    #endif
    //##########################################################################################################
    //                                      MSGQ_PARAMETERS
    //##########################################################################################################
    // msgq_id[i]                      =           q_creator(i);                   
    // msgq_id[no_queues - 1]          =           q_creator(no_queues - 1);       
    // printf("Rece: %d MQ_ID: %d... Waiting.\n", i, msgq_id[i]);
    //##########################################################################################################
    //                      BUFF TO KEEP TRACK OF THE BEAM NO
    //##########################################################################################################
    // char child_counter8[20];    
    // snprintf(child_counter8, sizeof(child_counter8) - 1, "Beam No %d",i);
    //##########################################################################################################
    //                                  DATA_RECEIVER_WHILE LOOP
    // int counter4 = 0;
    // long int oldtime = 0;
    double az = 0;
    uint32_t    A07_child_counter    =   0;
    //##########################################################################################################    
    while(1){
        //##########################################################################################################
        //                      EXTRACT THE DATA FROM THE RESPECTIVE QUEUE
        //##########################################################################################################  
        ssize_t bytesRece = msgrcv(msgq_id[i], &msgq_4224_64_sv, sizeof(msgq_4224_64_sv.data_4224_64_sv), 1, 0);
        if (bytesRece == -1) {
            perror("CHILD:msgrcv_child");
            exit(1);
        }    
    
        clock_gettime(CLOCK_MONOTONIC, &start);
        time_t current_time;
        struct tm *time_info;
        struct timeval ts;
        char time_str[100];
        time(&current_time);
        time_info = localtime(&current_time);
        gettimeofday(&ts, NULL);
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);

        #if LOG_FLAG * MSG_CHILD_FLAG
            fprintf(Msgrcv8child_log,"Receive_Time::, Captured Bytes::\n");
            fflush(Msgrcv8child_log);
        #endif

        #if LOG_FLAG * MSG_CHILD_FLAG
            fprintf(Msgrcv8child_log,"%s.%.06ld,%ld\n", time_str, (long) ts.tv_usec, bytesRece - INFO_PACKET_SIZE);
            fflush(Msgrcv8child_log);
        #endif
        //##########################################################################################################
        //                          WRITE THE RECEIVED DATA IN THE FILE
        //##########################################################################################################
        #if DATA_FLAG * MSG_CHILD_FLAG
            fwrite(msgq_struct.buffer, 1, bytesRece, Msgrcv8child_datalog);
            fflush(Msgrcv8child_datalog);
        #endif
        
        // printf("Hlo from child 3\n");

        // for (int beam_loop = 0; beam_loop < BEAM_COUNT; beam_loop++){
        //     // memcpy(childdata_buff + m, msgq_struct.buffer + INFO_PACKET_SIZE + (PULSE_DATA_SIZE + INFO_PACKET_SIZE) * m, PULSE_DATA_SIZE);   
 
        //     // memcpy(info_header_s_v + m, msgq_struct.buffer + (PULSE_DATA_SIZE + INFO_PACKET_SIZE) * m, INFO_PACKET_SIZE);              
        //     memcpy(info_header_s_v + beam_loop, &msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop], INFO_PACKET_SIZE);
        // }

        //##########################################################################################################
        //                          CONVERT THE RECEIVED DATA INTO INT
        //##########################################################################################################
        // uint32_t loop;
        // uint32_t Q_index;
        // uint32_t I_index;
        int newQ_buff_8192[8192]= {0};
        int newI_buff_8192[8192]= {0};

        for (uint32_t beam_loop = 0; beam_loop < BEAM_COUNT; beam_loop++){

            for(int pulse_loop = 0; pulse_loop < PULSE_COUNT; pulse_loop++){
                for(int sample_loop = 0; sample_loop < NUM_SAMPLES; sample_loop++){            

                    //Change to ntohs
                    newQ_buff_8192[sample_loop + pulse_loop * NUM_SAMPLES] = (int)htons(msgq_4224_64_sv.data_4224_64_sv.sample_QI_3D_uv[pulse_loop][sample_loop][beam_loop].sample_QI_struct_sv.Q_value);
                    newI_buff_8192[sample_loop + pulse_loop * NUM_SAMPLES] = (int)htons(msgq_4224_64_sv.data_4224_64_sv.sample_QI_3D_uv[pulse_loop][sample_loop][beam_loop].sample_QI_struct_sv.I_value);
                    // printf("Hello: %04x\n", ntohs(msgq_4224_64_sv.data_4224_64_sv.sample_QI_3D_uv[pulse_loop][sample_loop][n].sample_QI_struct_sv.Q_value));
                }
            }

            #if DATA_FLAG * MSG_CHILD_FLAG
                        // fprintf(QI_datalog,"%d,%d\n",newI_buff_8192[n][loop], newQ_buff_8192[n][loop]);
                        // fflush(QI_datalog);
                        // fwrite(AllData_2d + beam_loop, 1, (INFO_PACKET_SIZE + PULSE_DATA_SIZE) * BEAM_COUNT, Matrix_datalog);
                        // fflush(Matrix_datalog);
                        fwrite(newQ_buff_8192, 1, (INFO_PACKET_SIZE + PULSE_DATA_SIZE) * BEAM_COUNT, QI_datalog);
                        fflush(QI_datalog);
            #endif
        
            SP_V1 (newI_buff_8192,  newQ_buff_8192,  np, fsz, RCout_data,  RCout_size, DCout_data, DCout_size, &Dcnt,
                    Ridx_data, Ridx_size, Peak_aRC,  Peak_aDP, Peak_RC,  Peak_DP,  CFARdB,Zero_DP,  SNR_Out);
            
            float RCout_f ;
            unsigned int T_Amb_Range[20]    = {0};
            unsigned int SRng               = 1000;
            unsigned int ERng               = ((ntohl(msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop].total_IQ)/64) * (30.0 * (5.0 / 6.328125)));
            unsigned int R_OFFset           = 20;
            float RR_per_RC                 = (30.0 * (5.0 / 6.328125));  //range resolution per range cell
            // float RR_per_RC          = 23.703703;   //range resolution per range cell
            // unsigned int RR_per_RC          = 30;   //range resolution per range cell
            unsigned int RRpus              = 150;   //range resolution per 
            unsigned int PW                 = ntohs(msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop].pw);
            // unsigned int Det_idx[20];
            unsigned int tot_valid_det      = 0;
            unsigned int temp_Rng           = 0;
            //Dcnt = 1;
            //##########################################################################################################
            //Fixed Data (should be sent one time only) //need to change
            //##########################################################################################################
            finalstBurstRpt.hdr.msgTyp                = 0x01;
            finalstBurstRpt.hdr.s_CSCI_ID             = 0x09;
            finalstBurstRpt.hdr.D_CSCI_ID             = 0x10;
            finalstBurstRpt.hdr.Ct                    = 0x00;
            finalstBurstRpt.hdr.rsvd1                 = 0x00;
            finalstBurstRpt.hdr.ack                   = 0x00;
            finalstBurstRpt.hdr.msgCounter            = 0x00;
            finalstBurstRpt.hdr.msgLen                = 0xAA;
            finalstBurstRpt.hdr.rsvd2                 = 0x00;       
            finalstBurstRpt.CSST                      = 0x08;
            // finalstBurstRpt.NB                        = Dcnt;
            finalstBurstRpt.rsvd1                     = 0x00;
            finalstBurstRpt.rcTime                    = ntohl(msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop].rc_time);
            //##########################################################################################################
            az = ((ntohl(msgq_4224_64_sv.data_4224_64_sv.info_header_sv[beam_loop].h13) >> 16) & 0xFFF) * 0.9;
                // 0.00549;            
            // Dcnt = 2;

            if(Dcnt > 0){
                time(&current_time);
                time_info = localtime(&current_time);
                gettimeofday(&ts, NULL);
                strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);
                // printf("Core %d, Beam, %d, IF %d\n", i, n, countnew);
                // printf("dcnt1 = %u\taz = %lf\n", Dcnt, az);
                // printf("ERng : %u\n",ERng);
                    for(unsigned int k = 0; k < Dcnt; k++){
                        RCout_f = (float)(RCout_data[k]/100.0);
                        //			xil_printf("RCout_f : %d\n\r",RCout_f);
                        temp_Rng = (((SRng + (((RCout_f) - 1) * RR_per_RC)) - ((PW/10) * RRpus)) + R_OFFset);
                        //    printf("temp_Rng : %u, SRng: %u, ERng: %u\n",temp_Rng, SRng, ERng);
                        if((temp_Rng > SRng) && (temp_Rng < ERng)){
                            T_Amb_Range[tot_valid_det] = (((SRng + (((RCout_f) - 1) * RR_per_RC)) - ((PW/10) * RRpus)) + R_OFFset);
                            // Det_idx[tot_valid_det] = k;
                            tot_valid_det++;
                                // printf("tot_valid_det : %u\n",tot_valid_det);
                        }   
                        // BurstRpt.brst[k].range         =  T_Amb_Range[k];
                        // if (tot_valid_det > 0){
                        //     printf("Core %d, Beam, %d, Dcntnew = %d, k = %d, AMBI: %u, Time: %s\n", i, n, Dcnt, k, T_Amb_Range[k], time_str);
                        //     // printf("tot_valid_det : %u\n",tot_valid_det);
                        // }           
                    }
                    // if (i == 1){
                    //     // printf("tot_valid_det : %u\n\n",tot_valid_det);
                    // }
            }
            else{
                tot_valid_det = 0;
            }
            if(tot_valid_det > 0){ 
                for(unsigned int value = 0; value < tot_valid_det; value++){
                    // printf("DCout %u\n",DCout_data[value]);
                    finalstBurstRpt.final_brst[value + finalstBurstRpt.NB].Burst_id     = value + 1;
                    finalstBurstRpt.final_brst[value + finalstBurstRpt.NB].rsvd2        = 0;
                    finalstBurstRpt.final_brst[value + finalstBurstRpt.NB].range        = T_Amb_Range[value];
                    // BurstRpt.brst[i].range             = T_Amb_Range[i];
                    // BurstRpt.brst[value].az            = az / 0.00549;
                    #if TARGET
                        az = az - (double)5*i;
                    #endif
                    // printf("%d = %lf\n", i, az);
                    finalstBurstRpt.final_brst[value + finalstBurstRpt.NB].az            = az / 0.00549;               
                    finalstBurstRpt.final_brst[value + finalstBurstRpt.NB].el            = 0x0f;
                }
                finalstBurstRpt.NB += tot_valid_det;
                
            }
            else{
                // printf("CHILD: Az %lf\n", az);
                
            }
            // printf("%d = %lf\n", i, az);
        }
        
        //##########################################################################################################
        //                      SEND THE OUTPUT TO THE COMBINED MESSAGE QUEUE
        //##########################################################################################################
        if (finalstBurstRpt.NB > 0){
            // for (int new = 0; new < finalstBurstRpt.NB; new++){
            //     printf("CHILD: Core %02d, , Dcnt = %02d, AMBI: %04u, Azi: %lf, FAzi: %u, Time: %s\n", i, Dcnt, finalstBurstRpt.final_brst[new].range, az,finalstBurstRpt.final_brst[new].az,time_str);
            //     }
            // printf("tot_valid_det : %u\n",tot_valid_det);
        }        
        else{
            finalstBurstRpt.final_brst[0].az            = az / 0.00549;               
            // printf("CHILD: Az %lf\n", az);
            // printf("CHILD: FAz %u\n", finalstBurstRpt.final_brst[0].az);
            // printf("CHILD: Core %02d, , Dcnt = %02d, AMBI: %04u, Azi: %lf, FAzi: %u, Time: %s\n", i, Dcnt, finalstBurstRpt.final_brst[0].range, az,finalstBurstRpt.final_brst[0].az,time_str);
        }
        memcpy(&my_msgbuf_combine_core_sv.finalstBurstRpt_msgq, &finalstBurstRpt, sizeof(finalstBurstRpt));
         
        // if (finalstBurstRpt.NB > 0){
        //     for (int new = 0; new < finalstBurstRpt.NB; new++){
        //         printf("Core %d, , Dcntnew = %d, AMBI: %u, Time: %s\n", i, Dcnt, 
        //             my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.final_brst[new].range, time_str);}
        //     // printf("tot_valid_det : %u\n",tot_valid_det);
        // } 

        if(msgsnd(msgq_id[no_queues - 1], &my_msgbuf_combine_core_sv, sizeof(my_msgbuf_combine_core_sv.finalstBurstRpt_msgq), 0) == -1){
            if(errno != EAGAIN){
                perror("CHILD:Msg send error\n");
            }
        }
        // if (i == 1){
        //     printf("CHILD: Child %d Az: %u\n", i, my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.final_brst[0].az);
        // }
        finalstBurstRpt.NB = 0;
        // clock_gettime(CLOCK_MONOTONIC, &end);
        // double elapsed = seconds_since(start, end);
        // printf("CHILD: RECE_SP_ALGO: %d Total CPU computation time: %.9f seconds\n", i, elapsed);         
        // End of the while for receiving the data
        clock_gettime(CLOCK_MONOTONIC, &end);
        // double elapsed = seconds_since(start, end);
        // static double elapsed_max = 0;
        // if(elapsed > elapsed_max)
        // {
        //     elapsed_max = elapsed;
        //     // if (i == 1){
        //         printf("CHILD: Core: %02d, %0.9f seconds\n", i, elapsed_max);
        //     // }
            
        // }
        // printf("CHILD: RECE_SP_ALGO: %d Total CPU computation time: %.9f seconds\n", i, elapsed);
        // Close output file when done
        // fclose(filepointer);
        // printf("CHILD: Receiver finished. Data saved to %s.\n", filename);
    }
}
