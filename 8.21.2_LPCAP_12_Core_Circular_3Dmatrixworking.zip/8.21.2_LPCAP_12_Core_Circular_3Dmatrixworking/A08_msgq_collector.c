#include "A00_parameters.h"

//##########################################################################################################
#define SERVER_PORT 51005
#define CLIENT_PORT 51002

// #define SERVER_PORT 51006
// #define CLIENT_PORT 51007
//##########################################################################################################

//##########################################################################################################
//                                      MSGQ_PARAMETERS
//##########################################################################################################
extern int msgq_id[no_queues];          //IDs for the 10 queues
extern struct msgq_char msgq_struct;

// extern struct my_msgbuf_combine msgq_combined;
finalstBurstRpt_t final_BurstRpt;
extern stBurstRpt_t BurstRpt;
// extern unBurst_t stBrtRpt;
extern stBurstRpt_t BurstRpt;
extern struct my_msgbuf_combine_core my_msgbuf_combine_core_sv;
//##########################################################################################################
FILE *Msgq_combine_log, *Msgq_combine_datalog;
//##########################################################################################################

//##########################################################################################################
//                                  REPORT_COLLECTOR
//##########################################################################################################
void msgq_collector() {

    //##########################################################################################################
    //                              Socket_Creation
    //##########################################################################################################
    int sock;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);
    
    ssize_t bytes_sent;

     // Step 1: Create a UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("COLLECT: Socket creation failed");
        exit(EXIT_FAILURE);
    }
    printf("COLLECT: Socket Created\n");

    // Step 2: Set up the server address
    memset(&server, 0, sizeof(server));
    server.sin_family               = AF_INET;
    server.sin_addr.s_addr          = INADDR_ANY;
    server.sin_port                 = htons(CLIENT_PORT);

     // Step 3: Bind the socket to the address and port
    if (bind(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("COLLECT: Bind failed");
        close(sock);
        exit(EXIT_FAILURE);
    }
    printf("COLLECT: Binding done\n");

    // Step 4: Set up the client address
    memset(&client, 0, sizeof(client));
    client.sin_family               = AF_INET;
    client.sin_port                 = htons(SERVER_PORT);
    client.sin_addr.s_addr          = inet_addr("192.168.1.90");  // Replace with actual client IP
    //##########################################################################################################
    
    //##########################################################################################################
    //                        OPEN A FILE TO WRITE THE REPORT
    //##########################################################################################################
     #if LOG_FLAG * MSG_COLLECTOR_FLAG
        const char *msgrcv_collector_path = get_file_path("LOG_FILES","MSGQ_COLLECTOR_LOG","A08_msgq_collector","txt");
        if(msgrcv_collector_path == NULL){
            exit(1);
        }
        Msgq_combine_log = fopen(msgrcv_collector_path,"wb");
        if (Msgq_combine_log == NULL){
            perror("COLLECT: Unable to open Msgrcv_log file.\n");
        }

        
    #endif

    #if DATA_FLAG * MSG_COLLECTOR_FLAG
        const char *msgrcv_collector_data_path = get_file_path("DATA_FILES","MSGQ_COLLECTOR_DATALOG","A08_msgq_collector","bin");
        if(msgrcv_collector_data_path == NULL){
            exit(1);
        }
        Msgq_combine_datalog = fopen(msgrcv_collector_data_path,"wb");
        if (Msgq_combine_datalog == NULL){
            perror("COLLECT: Unable to open Msgrcv_datalog file.\n");
        }    
    #endif

        
    //##########################################################################################################
    //                          OPEN A MSG TO GET THE DATA
    //##########################################################################################################
    msgq_id[no_queues - 1]          = q_creator(no_queues - 1);
    printf("COLLECT: from collector Receiver %d... Waiting.\n", msgq_id[no_queues - 1]);

    //##########################################################################################################
    //                  TRIAL - OUTPUT FILE FOR PRINTING TIME
    //##########################################################################################################
    // FILE *time_report;
    //     time_report                 = fopen("00time.bin","wb");
    //     if(time_report              == NULL){
    //         printf("COLLECT: file not open time.bin");
    //     }
    
    //##########################################################################################################
    //          WHILE_LOOP TO START RECEIVING THE DATA FROM THE 8 QUEUES
    //##########################################################################################################
    uint32_t    A08_collector_counter    =   0;
    while (1) {
        // while(1);
    //##########################################################################################################
    //                      TRIAL - OUTPUT FILE FOR PRINTING TIME
    //##########################################################################################################
        time_t current_time;
        struct tm *time_info;
        struct timeval ts;
        char time_str[100];
        time(&current_time);
        time_info               = localtime(&current_time);
        gettimeofday(&ts, NULL);
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);
        // printf("Combine PROCESS STARTED: %s.%06ld\n", time_str, ts.tv_usec);
        // fprintf(time_report,"RT: %s.%06ld\n", time_str, ts.tv_usec);
        // fflush(time_report);
        #if LOG_FLAG * MSG_COLLECTOR_FLAG
            fprintf(Msgq_combine_log,"Receive_Time::, Captured Bytes::\n");
            fflush(Msgq_combine_log);
        #endif
    //##########################################################################################################
    //               TRIAL - END OF OUTPUT FILE FOR PRINTING TIME
    //##########################################################################################################
    //##########################################################################################################
    //               EXTARCT THE DATA FROM THE COLLECTOR MESSAGE BASED ON BEAM ORDER
    //##########################################################################################################
           // printf("It:%05d \n",combined_output_counter);
            // int offset       =   0;
            uint32_t sentBytes    =   0;
            // int k;

            for (unit32_t beam_loop  = 0; beam_loop < CORE_COUNT; beam_loop++){    
                // if (beam_loop == 0){
                //     memset(&final_BurstRpt,0,sizeof(final_BurstRpt));
                // }
                // while(1);
                ssize_t size_rece = msgrcv(msgq_id[no_queues - 1], &my_msgbuf_combine_core_sv, sizeof(my_msgbuf_combine_core_sv.finalstBurstRpt_msgq), beam_loop, 0);
                if (size_rece == -1) {
                    perror("COLLECT: msgrcv");
                    exit(1);
                } 

                #if LOG_FLAG * MSG_COLLECTOR_FLAG
                    fprintf(Msgq_combine_log,"%s.%.06ld, %ld\n", time_str, (long) ts.tv_usec, size_rece);
                    fflush(Msgq_combine_log);
                #endif

                
                memcpy(&final_BurstRpt, &my_msgbuf_combine_core_sv.finalstBurstRpt_msgq, sizeof(my_msgbuf_combine_core_sv.finalstBurstRpt_msgq));

                if(my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB > 0){
                    // memcpy(&final_BurstRpt, &my_msgbuf_combine_core_sv.finalstBurstRpt_msgq, sentBytes);
                    for (int new = 0; new < my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB; new++){
                        printf("COLLECT: Dcnt: %u, AMBI: %u, FAzi: %u, Time: %s\n",
                        final_BurstRpt.NB, final_BurstRpt.final_brst[new].range, final_BurstRpt.final_brst[new].az, time_str);
                    }
                        // printf("tot_valid_det : %u\n",tot_valid_det);
                    // } 
                    // offset += final_BurstRpt.NB;
                    final_BurstRpt.NB = my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB;
                    sentBytes = final_BurstRpt.NB * 12 + 20;
                    printf("COLLECT: have to send %d, M_az: %u, F_az: %u\n", sentBytes,
                            my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.final_brst[0].az,
                            final_BurstRpt.final_brst[0].az);
                    // if (final_BurstRpt.NB > 0 )
                    //     printf("BB beam_loop: %d, curr_det : %u tot_det : %u\n", beam_loop , my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB, final_BurstRpt.NB);
                    // sentBytes = final_BurstRpt.NB * 12 + 20;
                }
                else{
                    memset(&final_BurstRpt, 0, sizeof(final_BurstRpt));

                    final_BurstRpt.final_brst[0].az        =   my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.final_brst[0].az;
                    // printf("ElseAz: %u\n", my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.final_brst[0].az);
                    // for (int new = 0; new < my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB; new++){
                        // printf("AMBI22: %u,Az :%u Time: %s\n", 
                        //     final_BurstRpt.final_brst[0].range,
                        //     final_BurstRpt.final_brst[0].az,
                        //      time_str);
                    // }
                    sentBytes = 1 * 12 + 20;
                }
                // if(final_BurstRpt.NB > 0){
                //     time_t current_time;
                //     struct tm *time_info;
                //     struct timeval ts;
                //     char time_str[100];
                //     time(&current_time);
                //     time_info               = localtime(&current_time);
                //     gettimeofday(&ts, NULL);
                //     strftime(time_str, sizeof(time_str), "%H:%M:%S", time_info);
                // }
                #if DATA_FLAG * MSG_COLLECTOR_FLAG
                    fwrite(&msgq_combined.BurstRpt, sizeof(msgq_combined.BurstRpt) , 1, Msgq_combine_datalog);
                    fflush(Msgq_combine_datalog);
                #endif
                //##########################################################################################################
                //                              Socket_Send
                //##########################################################################################################
                // if(final_BurstRpt.NB > 0){
                // int k;
                // for (k = 0; k < final_BurstRpt.NB; k++){
                //     // printf("k = %d, NB: %d ID :%d Range %d\n", k, final_BurstRpt.NB, final_BurstRpt.final_brst[k].Burst_id, final_BurstRpt.final_brst[k].range);
                // }
                bytes_sent = sendto(sock, &final_BurstRpt, sentBytes, 0, (struct sockaddr *)&client, client_len);
                if (bytes_sent < 0) {
                    perror("COLLECT: Failed to send file data");
                    //fclose(fp);
                    close(sock);
                // close(server_sock);
                    //return 1;
                }
                // printf("I have sent %d\n", sentBytes);
                // printf("I have sent %d, M_az: %u, F_az: %u\n", sentBytes,
                //             final_BurstRpt.final_brst[0].az,
                //             final_BurstRpt.final_brst[0].az);
                if(final_BurstRpt.NB > 0){
                    for (uint32_t new = 0; new < my_msgbuf_combine_core_sv.finalstBurstRpt_msgq.NB; new++){
                        printf("COLLECT: Sent AMBI: %05u, Az: %03.0lf, FAz :%05u, Time: %s\n", 
                            final_BurstRpt.final_brst[new].range,
                            final_BurstRpt.final_brst[new].az * 0.00549,
                            final_BurstRpt.final_brst[new].az,
                            time_str);
                        }
                    // while(1);
                }
                else {
                    // printf("Sent AMBI: %05u, Az: %03.0lf, FAz :%05u, Time: %s\n", 
                    //             final_BurstRpt.final_brst[0].range,
                    //             final_BurstRpt.final_brst[0].az * 0.00549,
                    //             final_BurstRpt.final_brst[0].az,
                    //              time_str);
                }

         
        }
    
    }
    fclose(Msgq_combine_datalog);
    //printf("Receiver finished. Data saved to %s.\n", output);
}
