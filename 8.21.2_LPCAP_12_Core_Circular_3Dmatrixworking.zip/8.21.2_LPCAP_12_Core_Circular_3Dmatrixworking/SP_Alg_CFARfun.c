/*
 * File: SP_Alg_CFARfun.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "SP_Alg_CFARfun.h"
#include "SP_V1_emxutil.h"
#include "SP_V1_rtwutil.h"
#include "SP_V1_types.h"
#include <math.h>
#include <string.h>

/* Function Definitions */
/*
 * pfas based estimation
 *
 * Arguments    : const emxArray_real_T *CFARin1
 *                double Nrangecells
 *                double Npulse
 *                emxArray_real_T *CFAR_Det
 *                emxArray_real_T *CFARout
 * Return Type  : void
 */
void SP_Alg_CFARfun(const emxArray_real_T *CFARin1, double Nrangecells,
                    double Npulse, emxArray_real_T *CFAR_Det,
                    emxArray_real_T *CFARout)
{
  emxArray_uint32_T *peak_det;
  double TNR;
  double leftlongavg;
  double leftshortavg;
  double rightavg;
  unsigned int CFARin_data[8192];
  int Tcell;
  int b_i;
  int b_loop_ub;
  unsigned int b_qY;
  int i;
  int i1;
  int i2;
  int j;
  int k;
  unsigned int leftlongsum;
  unsigned int leftshortsum;
  int loop_ub;
  int loop_ub_tmp;
  int pdetcount;
  unsigned int qY;
  unsigned int rightsum;
  unsigned int u;
  signed char tgt_est_data[8192];
  if (1.0 > Nrangecells) {
    loop_ub = 0;
  } else {
    loop_ub = (int)Nrangecells;
  }
  if (1.0 > Npulse) {
    b_loop_ub = 0;
  } else {
    b_loop_ub = (int)Npulse;
  }
  for (i = 0; i < b_loop_ub; i++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      leftshortavg = rt_roundd(CFARin1->data[i1 + 128 * i]);
      if (leftshortavg < 4.294967296E+9) {
        if (leftshortavg >= 0.0) {
          u = (unsigned int)leftshortavg;
        } else {
          u = 0U;
        }
      } else {
        u = MAX_uint32_T;
      }
      CFARin_data[i1 + loop_ub * i] = u;
    }
  }
  /*  Noise theshold */
  if (Nrangecells == 128.0) {
    leftshortavg = 1.0E-6;
  } else {
    leftshortavg = 0.0001;
  }
  TNR = sqrt(-2.0 * log10(leftshortavg) / 0.43429448190325187) * 1.5;
  /*  Training Cell Estimation */
  if (ceil((Nrangecells / 2.0 - 2.0) - 1.0) > 32.0) {
    Tcell = 32;
  } else {
    Tcell = 128;
  }
  /*  Initialize variables */
  /*  keep double to maintain resolution */
  /*  det_count   = 0; */
  i = CFARout->size[0] * CFARout->size[1];
  CFARout->size[0] = loop_ub;
  CFARout->size[1] = b_loop_ub;
  emxEnsureCapacity_real_T(CFARout, i);
  loop_ub_tmp = loop_ub * b_loop_ub;
  for (i = 0; i < loop_ub_tmp; i++) {
    CFARout->data[i] = 0.0;
  }
  if (0 <= loop_ub_tmp - 1) {
    memset(&tgt_est_data[0], 0, loop_ub_tmp * sizeof(signed char));
  }
  leftshortavg = rt_roundd((Nrangecells - (double)Tcell) - 2.0);
  if (leftshortavg < 4.294967296E+9) {
    if (leftshortavg >= 0.0) {
      u = (unsigned int)leftshortavg;
    } else {
      u = 0U;
    }
  } else {
    u = MAX_uint32_T;
  }
  /*  temp variables */
  /*  CFAR Estimation */
  i = (int)Npulse;
  for (b_i = 0; b_i < i; b_i++) {
    leftlongsum = 0U;
    rightsum = 0U;
    i1 = (int)Nrangecells;
    for (j = 0; j < i1; j++) {
      leftshortsum = 0U;
      if (j + 1U < (unsigned int)(Tcell + 3)) {
        leftlongsum = 0U;
        if (j + 1U == 1U) {
          b_loop_ub = loop_ub * b_i;
          rightsum = CFARin_data[b_loop_ub + 3];
          for (k = 2; k <= Tcell; k++) {
            qY = rightsum + CFARin_data[(k + b_loop_ub) + 2];
            if (qY < rightsum) {
              qY = MAX_uint32_T;
            }
            rightsum = qY;
          }
          /*                   rs(j,i)     = rightsum; */
        } else {
          qY =
              rightsum +
              CFARin_data[((int)((unsigned int)Tcell + j) + loop_ub * b_i) + 2];
          if (qY < rightsum) {
            qY = MAX_uint32_T;
          }
          rightsum = qY - CFARin_data[(j + loop_ub * b_i) + 2];
          if (rightsum > qY) {
            rightsum = 0U;
          }
          /*                   rs(j,i)     = rightsum; */
        }
      } else if ((j + 1U >= (unsigned int)(Tcell + 3)) && (j + 1U < u)) {
        if (j + 1U == (unsigned int)(Tcell + 3)) {
          i2 = (int)(((double)j + 1.0) - ((double)Tcell - 2.0));
          if (i2 >= 0) {
            leftlongsum = (unsigned int)i2;
          } else {
            leftlongsum = 0U;
          }
          if (j - 2 >= 0) {
            b_qY = j - 2U;
          } else {
            b_qY = 0U;
          }
          if (leftlongsum > b_qY) {
            i2 = -1;
            b_loop_ub = -1;
          } else {
            i2 = (int)leftlongsum - 2;
            b_loop_ub = (int)b_qY - 1;
          }
          b_loop_ub -= i2;
          if (b_loop_ub == 0) {
            leftlongsum = 0U;
          } else {
            pdetcount = loop_ub * b_i;
            leftlongsum = CFARin_data[(i2 + pdetcount) + 1];
            for (k = 2; k <= b_loop_ub; k++) {
              qY = leftlongsum + CFARin_data[(i2 + k) + pdetcount];
              if (qY < leftlongsum) {
                qY = MAX_uint32_T;
              }
              leftlongsum = qY;
            }
          }
          /*                  lls(j,i)   = leftlongsum; */
        } else {
          qY = leftlongsum + CFARin_data[(j + loop_ub * b_i) - 3];
          if (qY < leftlongsum) {
            qY = MAX_uint32_T;
          }
          i2 = (int)(((double)j + 1.0) - ((double)Tcell - 2.0));
          if (i2 >= 0) {
            leftlongsum = (unsigned int)i2;
          } else {
            leftlongsum = 0U;
          }
          b_qY = leftlongsum - 1U;
          if (leftlongsum - 1U > leftlongsum) {
            b_qY = 0U;
          }
          leftlongsum = qY - CFARin_data[((int)b_qY + loop_ub * b_i) - 1];
          if (leftlongsum > qY) {
            leftlongsum = 0U;
          }
          /*                  lls(j,i)    = leftlongsum; */
        }
        qY = rightsum +
             CFARin_data[((int)((unsigned int)Tcell + j) + loop_ub * b_i) + 2];
        if (qY < rightsum) {
          qY = MAX_uint32_T;
        }
        rightsum = qY - CFARin_data[(j + loop_ub * b_i) + 2];
        if (rightsum > qY) {
          rightsum = 0U;
        }
        /*              rs(j,i)    = rightsum; */
      } else if (j + 1U >= u) {
        b_loop_ub = loop_ub * b_i;
        qY = leftlongsum + CFARin_data[(j + b_loop_ub) - 3];
        if (qY < leftlongsum) {
          qY = MAX_uint32_T;
        }
        i2 = (int)(((double)j + 1.0) - ((double)Tcell - 2.0));
        if (i2 >= 0) {
          leftlongsum = (unsigned int)i2;
        } else {
          leftlongsum = 0U;
        }
        b_qY = leftlongsum - 1U;
        if (leftlongsum - 1U > leftlongsum) {
          b_qY = 0U;
        }
        leftlongsum = qY - CFARin_data[((int)b_qY + b_loop_ub) - 1];
        if (leftlongsum > qY) {
          leftlongsum = 0U;
        }
        /*              lls(j,i)    = leftlongsum; */
        rightsum = 0U;
        /*              rs(j,i)     = rightsum; */
      }
      if (j + 1U > 26U) {
        for (b_loop_ub = 0; b_loop_ub < 8; b_loop_ub++) {
          leftshortavg = (double)leftshortsum +
                         (double)CFARin_data[(((int)(((double)j + 1.0) - 2.0) -
                                               b_loop_ub * 3) +
                                              loop_ub * b_i) -
                                             2];
          if (leftshortavg < 4.294967296E+9) {
            leftshortsum = (unsigned int)leftshortavg;
          } else {
            leftshortsum = MAX_uint32_T;
          }
          /*                  lss(j,i)     = leftshortsum; */
        }
      }
      leftshortavg = (double)leftshortsum / 8.0;
      leftlongavg = (double)leftlongsum / (double)Tcell;
      rightavg = (double)rightsum / (double)Tcell;
      if (leftlongavg > leftshortavg) {
        leftshortavg = leftlongavg;
        /*              la(j,i)  = leftlongavg; */
      } else {
        /*              la(j,i)  = leftshortavg; */
      }
      if (leftshortavg >= rightavg) {
        rightavg = leftshortavg;
      }
      leftshortavg = (double)CFARin_data[j + loop_ub * b_i] / rightavg;
      CFARout->data[j + CFARout->size[0] * b_i] = leftshortavg;
      /*         %% Target estimate based on CFAR */
      tgt_est_data[j + loop_ub * b_i] = (signed char)(leftshortavg > TNR);
    }
  }
  emxInit_uint32_T(&peak_det, 2);
  pdetcount = -1;
  i1 = peak_det->size[0] * peak_det->size[1];
  peak_det->size[0] = loop_ub_tmp;
  peak_det->size[1] = 5;
  emxEnsureCapacity_uint32_T(peak_det, i1);
  b_loop_ub = loop_ub_tmp * 5;
  for (i1 = 0; i1 < b_loop_ub; i1++) {
    peak_det->data[i1] = 0U;
  }
  i1 = (int)Nrangecells;
  for (k = 0; k < i1; k++) {
    for (b_loop_ub = 0; b_loop_ub < i; b_loop_ub++) {
      if (tgt_est_data[k + loop_ub * b_loop_ub] == 1) {
        pdetcount++;
        /*  cfar_amp(k,l) = cfar(k,l); */
        /*  det=[pdetcount,k,l,CFARin(k,l),pdetflag]; */
        /*  peak_det=[peak_det;det]; */
        peak_det->data[pdetcount] = (unsigned int)(pdetcount + 1);
        peak_det->data[pdetcount + peak_det->size[0]] = k + 1U;
        peak_det->data[pdetcount + peak_det->size[0] * 2] = b_loop_ub + 1U;
        peak_det->data[pdetcount + peak_det->size[0] * 3] =
            CFARin_data[k + loop_ub * b_loop_ub];
        peak_det->data[pdetcount + peak_det->size[0] * 4] = 1U;
      }
    }
  }
  /*  output variables for processing */
  if (1 > pdetcount + 1) {
    loop_ub = -1;
  } else {
    loop_ub = pdetcount;
  }
  i = CFAR_Det->size[0] * CFAR_Det->size[1];
  CFAR_Det->size[0] = loop_ub + 1;
  CFAR_Det->size[1] = 5;
  emxEnsureCapacity_real_T(CFAR_Det, i);
  for (i = 0; i < 5; i++) {
    for (i1 = 0; i1 <= loop_ub; i1++) {
      CFAR_Det->data[i1 + CFAR_Det->size[0] * i] =
          peak_det->data[i1 + peak_det->size[0] * i];
    }
  }
  emxFree_uint32_T(&peak_det);
}

/*
 * File trailer for SP_Alg_CFARfun.c
 *
 * [EOF]
 */
