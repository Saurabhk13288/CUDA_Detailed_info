/*
 * File: SP_Alg_Peakfun.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "SP_Alg_Peakfun.h"
#include "SP_V1_emxutil.h"
#include "SP_V1_rtwutil.h"
#include "SP_V1_types.h"
#include <math.h>
#include <string.h>

/* Function Definitions */
/*
 * Arguments    : const emxArray_real_T *PEAKin
 *                unsigned int Peaks_det[32]
 *                unsigned int *Num_det
 * Return Type  : void
 */
void SP_Alg_Peakfun(const emxArray_real_T *PEAKin, unsigned int Peaks_det[32],
                    unsigned int *Num_det)
{
  emxArray_real_T *peak_det;
  emxArray_real_T *peak_det1;
  emxArray_real_T *peak_fdet;
  double peak_pkdet1[32];
  double temp;
  double temp1;
  double temp2;
  int count;
  int count1;
  int i;
  int i1;
  int i2;
  int j;
  int k;
  int loop_ub;
  int pdetcount;
  unsigned int u;
  emxInit_real_T(&peak_det, 2);
  i = peak_det->size[0] * peak_det->size[1];
  peak_det->size[0] = PEAKin->size[0];
  peak_det->size[1] = 5;
  emxEnsureCapacity_real_T(peak_det, i);
  loop_ub = PEAKin->size[0] * 5;
  for (i = 0; i < loop_ub; i++) {
    peak_det->data[i] = PEAKin->data[i];
  }
  pdetcount = PEAKin->size[0];
  /*  Initialize Variables */
  i = PEAKin->size[0];
  for (k = 0; k < i; k++) {
    i1 = pdetcount - k;
    for (j = 0; j <= i1 - 2; j++) {
      loop_ub = (k + j) + 1;
      if (peak_det->data[k + peak_det->size[0] * 3] <
          peak_det->data[loop_ub + peak_det->size[0] * 3]) {
        temp = peak_det->data[k + peak_det->size[0]];
        temp1 = peak_det->data[k + peak_det->size[0] * 2];
        temp2 = peak_det->data[k + peak_det->size[0] * 3];
        peak_det->data[k + peak_det->size[0]] =
            peak_det->data[loop_ub + peak_det->size[0]];
        peak_det->data[k + peak_det->size[0] * 2] =
            peak_det->data[loop_ub + peak_det->size[0] * 2];
        peak_det->data[k + peak_det->size[0] * 3] =
            peak_det->data[loop_ub + peak_det->size[0] * 3];
        peak_det->data[loop_ub + peak_det->size[0]] = temp;
        peak_det->data[loop_ub + peak_det->size[0] * 2] = temp1;
        peak_det->data[loop_ub + peak_det->size[0] * 3] = temp2;
      }
    }
  }
  emxInit_real_T(&peak_det1, 2);
  count = -1;
  count1 = -1;
  i = peak_det1->size[0] * peak_det1->size[1];
  peak_det1->size[0] = PEAKin->size[0];
  peak_det1->size[1] = 5;
  emxEnsureCapacity_real_T(peak_det1, i);
  loop_ub = PEAKin->size[0] * 5;
  for (i = 0; i < loop_ub; i++) {
    peak_det1->data[i] = 0.0;
  }
  emxInit_real_T(&peak_fdet, 2);
  i = peak_fdet->size[0] * peak_fdet->size[1];
  peak_fdet->size[0] = PEAKin->size[0];
  peak_fdet->size[1] = 5;
  emxEnsureCapacity_real_T(peak_fdet, i);
  loop_ub = PEAKin->size[0] * 5;
  for (i = 0; i < loop_ub; i++) {
    peak_fdet->data[i] = 0.0;
  }
  i = PEAKin->size[0];
  for (k = 0; k < i; k++) {
    if (peak_det->data[k + peak_det->size[0] * 4] == 1.0) {
      if (k + 1 < pdetcount) {
        i1 = pdetcount - k;
        for (j = 0; j <= i1 - 2; j++) {
          loop_ub = (k + j) + 1;
          if (((fabs(peak_det->data[k + peak_det->size[0]] -
                     peak_det->data[loop_ub + peak_det->size[0]]) <= 5.0) ||
               (fabs(peak_det->data[k + peak_det->size[0] * 2] -
                     peak_det->data[loop_ub + peak_det->size[0] * 2]) <=
                5.0)) &&
              (peak_det->data[loop_ub + peak_det->size[0] * 4] == 1.0)) {
            peak_det->data[loop_ub + peak_det->size[0] * 4] = 0.0;
          }
        }
      } else if (k + 1 == pdetcount) {
        peak_det->data[k + peak_det->size[0] * 4] = 0.0;
      }
      peak_det->data[k + peak_det->size[0] * 4] = 0.0;
      if (k + 1 < pdetcount) {
        i1 = pdetcount - k;
        for (j = 0; j < i1; j++) {
          loop_ub = k + j;
          if (peak_det->data[loop_ub + peak_det->size[0] * 4] == 0.0) {
            count++;
            for (i2 = 0; i2 < 5; i2++) {
              peak_det1->data[count + peak_det1->size[0] * i2] =
                  peak_det->data[loop_ub + peak_det->size[0] * i2];
            }
          }
        }
      } else if (k + 1 == pdetcount) {
        for (i1 = 0; i1 < 5; i1++) {
          peak_det1->data[peak_det1->size[0] * i1] =
              peak_det->data[k + peak_det->size[0] * i1];
        }
      }
      count1++;
      for (i1 = 0; i1 < 5; i1++) {
        peak_fdet->data[count1 + peak_fdet->size[0] * i1] =
            peak_det1->data[peak_det1->size[0] * i1];
      }
    }
    count = -1;
  }
  emxFree_real_T(&peak_det1);
  emxFree_real_T(&peak_det);
  memset(&peak_pkdet1[0], 0, 32U * sizeof(double));
  for (k = 0; k <= count1; k++) {
    peak_pkdet1[k] = k + 1;
    peak_pkdet1[k + 8] = peak_fdet->data[k + peak_fdet->size[0]];
    peak_pkdet1[k + 16] = peak_fdet->data[k + peak_fdet->size[0] * 2];
    peak_pkdet1[k + 24] = peak_fdet->data[k + peak_fdet->size[0] * 3];
  }
  emxFree_real_T(&peak_fdet);
  /*  assign output variables */
  for (i = 0; i < 32; i++) {
    temp = rt_roundd(peak_pkdet1[i]);
    if (temp < 4.294967296E+9) {
      if (temp >= 0.0) {
        u = (unsigned int)temp;
      } else {
        u = 0U;
      }
    } else {
      u = MAX_uint32_T;
    }
    Peaks_det[i] = u;
  }
  *Num_det = (unsigned int)(count1 + 1);         //Ankush
  // *Num_det = (unsigned int)(10);         //Ankush
}

/*
 * File trailer for SP_Alg_Peakfun.c
 *
 * [EOF]
 */
