/*
 * File: SP_Alg_Peakfun.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

#ifndef SP_ALG_PEAKFUN_H
#define SP_ALG_PEAKFUN_H

/* Include Files */
#include "SP_V1_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void SP_Alg_Peakfun(const emxArray_real_T *PEAKin, unsigned int Peaks_det[32],
                    unsigned int *Num_det);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for SP_Alg_Peakfun.h
 *
 * [EOF]
 */
