/*
 * File: SP_V1.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "SP_V1.h"
#include "FFTImplementationCallback.h"
#include "SP_Alg_CFARfun.h"
#include "SP_Alg_Peakfun.h"
#include "SP_V1_emxutil.h"
#include "SP_V1_rtwutil.h"
#include "SP_V1_types.h"
#include "fft.h"
#include "ifft.h"
#include <math.h>
#include <string.h>
#include<stdio.h>

/* Function Declarations */
static double rt_hypotd(double u0, double u1);

/* Function Definitions */
/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd(double u0, double u1)
{
  double a;
  double b;
  double y;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else {
    y = a * 1.4142135623730951;
  }
  return y;
}

/*
 * Arguments    : const int idata[8192]
 *                const int qdata[8192]
 *                unsigned int np
 *                unsigned int fsz
 *                unsigned int RCout_data[]
 *                int RCout_size[1]
 *                unsigned int DCout_data[]
 *                int DCout_size[1]
 *                unsigned int *Dcnt
 *                unsigned int Ridx_data[]
 *                int Ridx_size[1]
 *                unsigned int Peak_aRC[40]
 *                unsigned int Peak_aDP[40]
 *                unsigned int Peak_RC[20]
 *                unsigned int Peak_DP[20]
 *                int CFARdB[20]
 *                unsigned int Zero_DP[20]
 *                int SNR_Out[20]
 * Return Type  : void
 */
void SP_V1(const int idata[8192], const int qdata[8192], unsigned int np,
           unsigned int fsz, unsigned int RCout_data[], int RCout_size[1],
           unsigned int DCout_data[], int DCout_size[1], unsigned int *Dcnt,
           unsigned int Ridx_data[], int Ridx_size[1],
           unsigned int Peak_aRC[40], unsigned int Peak_aDP[40],
           unsigned int Peak_RC[20], unsigned int Peak_DP[20], int CFARdB[20],
           unsigned int Zero_DP[20], int SNR_Out[20])
{
  emxArray_creal_T c_data_in;
  emxArray_creal_T *b_data_in;
  emxArray_creal_T *cplx_out;
  emxArray_creal_T *d_data_in;
  emxArray_creal_T *data_in;
  emxArray_creal_T *insig_out;
  emxArray_creal_T *pcCoeff;
  emxArray_creal_T *r;
  emxArray_creal_T *yCol;
  emxArray_real_T *CFAR_Det;
  emxArray_real_T *CFARout;
  emxArray_real_T *DPout;
  emxArray_real_T *Den;
  emxArray_real_T *Num;
  emxArray_real_T *dp_linear;
  emxArray_real_T *dp_out;
  emxArray_real_T *sintab;
  emxArray_real_T *sintabinv;
  emxArray_real_T *y;
  double cent_dop[8];
  double cent_range[8];
  double den[5];
  double num[5];
  double arc;
  double d;
  double j;
  double num_tmp;
  unsigned int a_data[8192];
  unsigned int b_data[8192];
  unsigned int PEAK_Det[32];
  unsigned int Ref_idx[20];
  int N2blue;
  int b_i;
  unsigned int b_y;
  int i;
  int i1;
  int i2;
  int i3;
  unsigned int k;
  int loop_ub;
  int loop_ub_tmp;
  int num_idx_0_tmp_tmp;
  int nx;
  unsigned int qY;
  boolean_T useRadix2;
  emxInit_creal_T(&data_in, 2);
  num_idx_0_tmp_tmp = (int)fsz;
  /*  subplot(3,1,1) */
  /*  plot(DAT_i,'r'); */
  /*  title('I DATA'); */
  /*  subplot(3,1,2) */
  /*  plot(DAT_q,'b'); */
  /*  title('Q DATA'); */
  /*  subplot(3,1,3) */
  /*  plot((MF_i),'g'); */
  /*  title('COE-I'); */
  /*  data in as complex */
  i = data_in->size[0] * data_in->size[1];
  data_in->size[0] = (int)np;
  data_in->size[1] = (int)fsz;
  emxEnsureCapacity_creal_T(data_in, i);
  for (i = 0; i < num_idx_0_tmp_tmp; i++) {
    loop_ub = (int)np;
    for (i1 = 0; i1 < loop_ub; i1++) {
      data_in->data[i1 + data_in->size[0] * i].re =
          (double)idata[i + (int)fsz * i1] / 32768.0;
      data_in->data[i1 + data_in->size[0] * i].im =
          (double)qdata[i + (int)fsz * i1] / 32768.0;
    }
  }
  emxInit_creal_T(&pcCoeff, 2);
  emxInit_creal_T(&insig_out, 2);
  /*  PC Section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   */
  /*  perform fft on the coeff data. */
  fft(fsz, pcCoeff);
  /*  figure; */
  /*  plot(abs(pcCoeff)); */
  /*  title('PC Coeff'); */
  /*  perform fft on the  data. */
  i = insig_out->size[0] * insig_out->size[1];
  insig_out->size[0] = (int)np;
  insig_out->size[1] = (int)fsz;
  emxEnsureCapacity_creal_T(insig_out, i);
  loop_ub_tmp = (int)np * (int)fsz;
  for (i = 0; i < loop_ub_tmp; i++) {
    insig_out->data[i].re = 0.0;
    insig_out->data[i].im = 0.0;
  }
  i = (int)np;
  emxInit_real_T(&dp_linear, 2);
  emxInit_creal_T(&yCol, 1);
  emxInit_real_T(&sintab, 2);
  emxInit_real_T(&sintabinv, 2);
  emxInit_creal_T(&b_data_in, 2);
  for (b_i = 0; b_i < i; b_i++) {
    loop_ub = data_in->size[1];
    if ((data_in->size[1] == 0) || (0 == (int)fsz)) {
      for (i1 = 0; i1 < num_idx_0_tmp_tmp; i1++) {
        insig_out->data[b_i + insig_out->size[0] * i1].re = 0.0;
        insig_out->data[b_i + insig_out->size[0] * i1].im = 0.0;
      }
    } else {
      useRadix2 = (((int)fsz > 0) && (((int)fsz & ((int)fsz - 1)) == 0));
      c_FFTImplementationCallback_get((int)fsz, useRadix2, &N2blue, &nx);
      c_FFTImplementationCallback_gen(nx, useRadix2, dp_linear, sintab,
                                      sintabinv);
      if (useRadix2) {
        i1 = b_data_in->size[0] * b_data_in->size[1];
        b_data_in->size[0] = 1;
        b_data_in->size[1] = data_in->size[1];
        emxEnsureCapacity_creal_T(b_data_in, i1);
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_data_in->data[i1] = data_in->data[b_i + data_in->size[0] * i1];
        }
        i1 = data_in->size[1];
        c_data_in = *b_data_in;
        i3 = i1;
        c_data_in.size = &i3;
        c_data_in.numDimensions = 1;
        c_FFTImplementationCallback_r2b(&c_data_in, (int)fsz, dp_linear, sintab,
                                        yCol);
      } else {
        i1 = b_data_in->size[0] * b_data_in->size[1];
        b_data_in->size[0] = 1;
        b_data_in->size[1] = data_in->size[1];
        emxEnsureCapacity_creal_T(b_data_in, i1);
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_data_in->data[i1] = data_in->data[b_i + data_in->size[0] * i1];
        }
        i1 = data_in->size[1];
        c_data_in = *b_data_in;
        i2 = i1;
        c_data_in.size = &i2;
        c_data_in.numDimensions = 1;
        c_FFTImplementationCallback_dob(&c_data_in, N2blue, (int)fsz, dp_linear,
                                        sintab, sintabinv, yCol);
      }
      for (i1 = 0; i1 < num_idx_0_tmp_tmp; i1++) {
        insig_out->data[b_i + insig_out->size[0] * i1] = yCol->data[i1];
      }
    }
  }
  emxFree_creal_T(&b_data_in);
  emxInit_creal_T(&cplx_out, 2);
  i = cplx_out->size[0] * cplx_out->size[1];
  cplx_out->size[0] = (int)np;
  cplx_out->size[1] = (int)fsz;
  emxEnsureCapacity_creal_T(cplx_out, i);
  for (i = 0; i < loop_ub_tmp; i++) {
    cplx_out->data[i].re = 0.0;
    cplx_out->data[i].im = 0.0;
  }
  i = (int)np;
  for (b_i = 0; b_i < i; b_i++) {
    loop_ub = pcCoeff->size[1];
    for (i1 = 0; i1 < loop_ub; i1++) {
      cplx_out->data[b_i + cplx_out->size[0] * i1].re =
          pcCoeff->data[i1].re *
              insig_out->data[b_i + insig_out->size[0] * i1].re -
          pcCoeff->data[i1].im *
              insig_out->data[b_i + insig_out->size[0] * i1].im;
      cplx_out->data[b_i + cplx_out->size[0] * i1].im =
          pcCoeff->data[i1].re *
              insig_out->data[b_i + insig_out->size[0] * i1].im +
          pcCoeff->data[i1].im *
              insig_out->data[b_i + insig_out->size[0] * i1].re;
    }
  }
  emxFree_creal_T(&insig_out);
  /*  figure; */
  /*  mesh(abs(cplx_out)); */
  /*  title('Complex Output'); */
  /*  Pulse Compression output */
  i = data_in->size[0] * data_in->size[1];
  data_in->size[0] = (int)np;
  data_in->size[1] = (int)fsz;
  emxEnsureCapacity_creal_T(data_in, i);
  for (i = 0; i < loop_ub_tmp; i++) {
    data_in->data[i].re = 0.0;
    data_in->data[i].im = 0.0;
  }
  i = (int)np;
  emxInit_creal_T(&r, 2);
  for (b_i = 0; b_i < i; b_i++) {
    loop_ub = cplx_out->size[1];
    i1 = pcCoeff->size[0] * pcCoeff->size[1];
    pcCoeff->size[0] = 1;
    pcCoeff->size[1] = cplx_out->size[1];
    emxEnsureCapacity_creal_T(pcCoeff, i1);
    for (i1 = 0; i1 < loop_ub; i1++) {
      pcCoeff->data[i1] = cplx_out->data[b_i + cplx_out->size[0] * i1];
    }
    ifft(pcCoeff, r);
    loop_ub = r->size[1];
    for (i1 = 0; i1 < loop_ub; i1++) {
      data_in->data[b_i + data_in->size[0] * i1] = r->data[i1];
    }
  }
  emxFree_creal_T(&r);
  emxFree_creal_T(&cplx_out);
  emxFree_creal_T(&pcCoeff);
  emxInit_real_T(&dp_out, 2);
  /*  figure; */
  /*  mesh(abs(pc_out)); */
  /*  title('PC Output'); */
  /*  DP Section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   */
  i = dp_out->size[0] * dp_out->size[1];
  dp_out->size[0] = (int)np;
  dp_out->size[1] = (int)fsz;
  emxEnsureCapacity_real_T(dp_out, i);
  for (i = 0; i < loop_ub_tmp; i++) {
    dp_out->data[i] = 0.0;
  }
  emxInit_real_T(&y, 1);
  emxInit_creal_T(&d_data_in, 1);
  for (b_i = 0; b_i < num_idx_0_tmp_tmp; b_i++) {
    loop_ub = data_in->size[0];
    if (data_in->size[0] == 0) {
      yCol->size[0] = 0;
    } else {
      useRadix2 = ((data_in->size[0] & (data_in->size[0] - 1)) == 0);
      c_FFTImplementationCallback_get(data_in->size[0], useRadix2, &N2blue,
                                      &nx);
      c_FFTImplementationCallback_gen(nx, useRadix2, dp_linear, sintab,
                                      sintabinv);
      if (useRadix2) {
        i = d_data_in->size[0];
        d_data_in->size[0] = data_in->size[0];
        emxEnsureCapacity_creal_T(d_data_in, i);
        for (i = 0; i < loop_ub; i++) {
          d_data_in->data[i] = data_in->data[i + data_in->size[0] * b_i];
        }
        c_FFTImplementationCallback_r2b(d_data_in, data_in->size[0], dp_linear,
                                        sintab, yCol);
      } else {
        i = d_data_in->size[0];
        d_data_in->size[0] = data_in->size[0];
        emxEnsureCapacity_creal_T(d_data_in, i);
        for (i = 0; i < loop_ub; i++) {
          d_data_in->data[i] = data_in->data[i + data_in->size[0] * b_i];
        }
        c_FFTImplementationCallback_dob(d_data_in, N2blue, data_in->size[0],
                                        dp_linear, sintab, sintabinv, yCol);
      }
    }
    nx = yCol->size[0];
    i = y->size[0];
    y->size[0] = yCol->size[0];
    emxEnsureCapacity_real_T(y, i);
    for (loop_ub_tmp = 0; loop_ub_tmp < nx; loop_ub_tmp++) {
      y->data[loop_ub_tmp] =
          rt_hypotd(yCol->data[loop_ub_tmp].re, yCol->data[loop_ub_tmp].im);
    }
    loop_ub = y->size[0];
    for (i = 0; i < loop_ub; i++) {
      dp_out->data[i + dp_out->size[0] * b_i] = y->data[i];
    }
  }
  emxFree_creal_T(&d_data_in);
  emxFree_real_T(&y);
  emxFree_real_T(&sintabinv);
  emxFree_real_T(&sintab);
  emxFree_creal_T(&yCol);
  emxFree_creal_T(&data_in);
  /*  figure; */
  /*  mesh(abs(dp_out)); */
  /*  title('DP Output'); */
  /*  linear convertion */
  i = dp_linear->size[0] * dp_linear->size[1];
  dp_linear->size[0] = 1;
  loop_ub_tmp = (int)((double)fsz * (double)np);
  dp_linear->size[1] = loop_ub_tmp;
  emxEnsureCapacity_real_T(dp_linear, i);
  for (i = 0; i < loop_ub_tmp; i++) {
    dp_linear->data[i] = 0.0;
  }
  k = 1U;
  for (b_i = 0; b_i < num_idx_0_tmp_tmp; b_i++) {
    i = (int)np;
    for (loop_ub_tmp = 0; loop_ub_tmp < i; loop_ub_tmp++) {
      dp_linear->data[(int)(k + loop_ub_tmp) - 1] =
          dp_out->data[loop_ub_tmp + dp_out->size[0] * b_i];
    }
    k += np;
  }
  emxFree_real_T(&dp_out);
  emxInit_real_T(&DPout, 2);
  /*  figure; */
  /*  plot(abs(dp_linear)); */
  /*  title('DP LINEAR OUTPUT'); */
  /*  CFAR Section %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   */
  /*  reference values */
  /*  guard cells                                                      */
  /*  reference cells */
  /*  short celld */
  /*  convertion to 2D */
  /*  for i=1:1:FSZ */
  /*      for j=1:1:NP */
  /*          DPout(i,j)         = CFAR_Din(((i-1)*NP)+j); */
  /*      end */
  /*  end */
  i = DPout->size[0] * DPout->size[1];
  DPout->size[0] = 128;
  DPout->size[1] = 64;
  emxEnsureCapacity_real_T(DPout, i);
  for (i = 0; i < 64; i++) {
    for (i1 = 0; i1 < 128; i1++) {
      DPout->data[i1 + 128 * i] = dp_linear->data[i + (i1 << 6)];
    }
  }
  emxFree_real_T(&dp_linear);
  emxInit_real_T(&CFAR_Det, 2);
  emxInit_real_T(&CFARout, 2);
  /*  CFAR Estimate */
  SP_Alg_CFARfun(DPout, fsz, np, CFAR_Det, CFARout);      ///one core  //
  /*  Peak Detection */
  SP_Alg_Peakfun(CFAR_Det, PEAK_Det, Dcnt);
  emxFree_real_T(&CFAR_Det);
  memset(&Peak_RC[0], 0, 20U * sizeof(unsigned int));
  memset(&Peak_DP[0], 0, 20U * sizeof(unsigned int));
  memset(&Ref_idx[0], 0, 20U * sizeof(unsigned int));
  memset(&Zero_DP[0], 0, 20U * sizeof(unsigned int));
  memset(&Peak_aRC[0], 0, 40U * sizeof(unsigned int));
  memset(&Peak_aDP[0], 0, 40U * sizeof(unsigned int));
  memset(&CFARdB[0], 0, 20U * sizeof(int));
  memset(&SNR_Out[0], 0, 20U * sizeof(int));
  loop_ub = (int)*Dcnt;
  /*  Range Centroiding */
  /*  Variable initialization */
  for (b_i = 0; b_i < loop_ub; b_i++) {
    k = PEAK_Det[b_i + 8];
    Peak_RC[b_i] = k;
    b_y = PEAK_Det[b_i + 16];
    Peak_DP[b_i] = b_y;
    /*     %% linear array reference estimation */
    qY = k - 1U;
    if (k - 1U > k) {
      qY = 0U;
    }
    arc = (double)qY * (double)np;
    if (arc < 4.294967296E+9) {
      k = (unsigned int)arc;
    } else {
      k = MAX_uint32_T;
    }
    qY = k + b_y;
    if (qY < k) {
      qY = MAX_uint32_T;
    }
    Ref_idx[b_i] = qY;
    arc = rt_roundd(
        20.0 *
        log10(CFARout->data[((int)Peak_RC[b_i] +
                             CFARout->size[0] * ((int)Peak_DP[b_i] - 1)) -
                            1]) *
        10.0);
    if (arc < 2.147483648E+9) {
      if (arc >= -2.147483648E+9) {
        i = (int)arc;
      } else {
        i = MIN_int32_T;
      }
    } else {
      i = MAX_int32_T;
    }
    CFARdB[b_i] = i;
    /*     %% rc adjacency calc */
    k = Peak_RC[b_i];
    b_y = Peak_DP[b_i];
    for (nx = 0; nx < 5; nx++) {
      arc = (double)k + ((double)nx + -2.0);
      if (arc < 1.0) {
        arc += (double)fsz;
      } else if (arc > fsz) {
        arc -= (double)fsz;
      }
      arc = rt_roundd(
          20.0 * log10(DPout->data[((int)arc + 128 * ((int)b_y - 1)) - 1]) *
          10.0);
      if (arc < 4.294967296E+9) {
        if (arc >= 0.0) {
          qY = (unsigned int)arc;
        } else {
          qY = 0U;
        }
      } else {
        qY = MAX_uint32_T;
      }
      Peak_aRC[nx] = qY;
      arc = (double)b_y + ((double)nx + -2.0);
      if (arc < 1.0) {
        arc += (double)np;
      } else if (arc > np) {
        arc -= (double)np;
      }
      arc = rt_roundd(20.0 *
                      log10(DPout->data[((int)k + 128 * ((int)arc - 1)) - 1]) *
                      10.0);
      if (arc < 4.294967296E+9) {
        if (arc >= 0.0) {
          qY = (unsigned int)arc;
        } else {
          qY = 0U;
        }
      } else {
        qY = MAX_uint32_T;
      }
      Peak_aDP[nx] = qY;
    }
    a_data[b_i] = 0U;
    b_data[b_i] = 0U;
  }
  memset(&cent_range[0], 0, 8U * sizeof(double));
  emxInit_real_T(&Num, 1);
  emxInit_real_T(&Den, 1);
  i = Num->size[0];
  Num->size[0] = (int)*Dcnt;
  emxEnsureCapacity_real_T(Num, i);
  i = Den->size[0];
  Den->size[0] = (int)*Dcnt;
  emxEnsureCapacity_real_T(Den, i);
  for (b_i = 0; b_i < loop_ub; b_i++) {
    arc = 0.0;
    d = 0.0;
    nx = -1;
    for (i = 0; i < 5; i++) {
      num[i] = 0.0;
      den[i] = 0.0;
    }
    qY = PEAK_Det[b_i + 8];
    a_data[b_i] = qY;
    b_data[b_i] = PEAK_Det[b_i + 16];
    i = (int)(((double)qY + 2.0) + (1.0 - ((double)qY - 2.0)));
    for (loop_ub_tmp = 0; loop_ub_tmp < i; loop_ub_tmp++) {
      j = ((double)a_data[b_i] - 2.0) + (double)loop_ub_tmp;
      if (j > fsz) {
        j = arc + 1.0;
        arc++;
      }
      if (j < 1.0) {
        j = (double)fsz - d;
        d++;
      }
      i1 = (int)b_data[b_i] - 1;
      if (CFARout->data[((int)j + CFARout->size[0] * i1) - 1] > 3.1623) {
        nx++;
        num_tmp = DPout->data[((int)j + 128 * i1) - 1];
        num[nx] = num_tmp * j;
        den[nx] = num_tmp;
      }
    }
    Num->data[b_i] = (((num[0] + num[1]) + num[2]) + num[3]) + num[4];
    Den->data[b_i] = (((den[0] + den[1]) + den[2]) + den[3]) + den[4];
    cent_range[b_i] = Num->data[b_i] / Den->data[b_i];
  }
  /*  Output variable */
  /*  Doppler Centroiding */
  /*  Variable initialization  */
  if (0 <= loop_ub - 1) {
    memset(&a_data[0], 0, loop_ub * sizeof(unsigned int));
    memset(&b_data[0], 0, loop_ub * sizeof(unsigned int));
  }
  memset(&cent_dop[0], 0, 8U * sizeof(double));
  /*  non- transponder mode only */
  if (np > 1U) {
    i = Num->size[0];
    Num->size[0] = (int)*Dcnt;
    emxEnsureCapacity_real_T(Num, i);
    i = Den->size[0];
    Den->size[0] = (int)*Dcnt;
    emxEnsureCapacity_real_T(Den, i);
    for (b_i = 0; b_i < loop_ub; b_i++) {
      nx = -1;
      arc = 0.0;
      d = 0.0;
      for (i = 0; i < 5; i++) {
        num[i] = 0.0;
        den[i] = 0.0;
      }
      a_data[b_i] = PEAK_Det[b_i + 8];
      qY = PEAK_Det[b_i + 16];
      b_data[b_i] = qY;
      i = (int)(((double)qY + 2.0) + (1.0 - ((double)qY - 2.0)));
      for (loop_ub_tmp = 0; loop_ub_tmp < i; loop_ub_tmp++) {
        j = ((double)b_data[b_i] - 2.0) + (double)loop_ub_tmp;
        if (j > np) {
          j = arc + 1.0;
          arc++;
        }
        if (j < 1.0) {
          j = (double)np - d;
          d++;
        }
        i1 = (int)a_data[b_i] - 1;
        if (CFARout->data[i1 + CFARout->size[0] * ((int)j - 1)] > 3.1623) {
          nx++;
          num_tmp = DPout->data[i1 + 128 * ((int)j - 1)];
          num[nx] = num_tmp * j;
          den[nx] = num_tmp;
        }
      }
      Num->data[b_i] = (((num[0] + num[1]) + num[2]) + num[3]) + num[4];
      Den->data[b_i] = (((den[0] + den[1]) + den[2]) + den[3]) + den[4];
      cent_dop[b_i] = Num->data[b_i] / Den->data[b_i];
    }
  }
  emxFree_real_T(&Den);
  emxFree_real_T(&Num);
  emxFree_real_T(&CFARout);
  /*     %% assign output variable */
  /*  Output Variable */
  for (b_i = 0; b_i < loop_ub; b_i++) {
    arc = rt_roundd(20.0 * log10(DPout->data[(int)Peak_RC[b_i] - 1]) * 10.0);
    if (arc < 4.294967296E+9) {
      if (arc >= 0.0) {
        qY = (unsigned int)arc;
      } else {
        qY = 0U;
      }
    } else {
      qY = MAX_uint32_T;
    }
    Zero_DP[b_i] = qY;
    qY = Peak_aDP[2] - 250U;
    if (Peak_aDP[2] - 250U > Peak_aDP[2]) {
      qY = 0U;
    }
    if (qY > 2147483647U) {
      qY = 2147483647U;
    }
    SNR_Out[b_i] = (int)qY;
  }
  emxFree_real_T(&DPout);
  RCout_size[0] = 8;
  DCout_size[0] = 8;
  for (i = 0; i < 8; i++) {
    arc = rt_roundd(cent_range[i] * 100.0);
    if (arc < 4.294967296E+9) {
      if (arc >= 0.0) {
        qY = (unsigned int)arc;
      } else {
        qY = 0U;
      }
    } else {
      qY = MAX_uint32_T;
    }

    //printf("qy :%u\n",qY);            //qy 15/07/2025

    RCout_data[i] = qY;
    arc = rt_roundd(cent_dop[i] / 0.1);
    if (arc < 4.294967296E+9) {
      if (arc >= 0.0) {
        qY = (unsigned int)arc;
      } else {
        qY = 0U;
      }
    } else {
      qY = MAX_uint32_T;
    }
    DCout_data[i] = qY;
  }
  Ridx_size[0] = 20;
  memcpy(&Ridx_data[0], &Ref_idx[0], 20U * sizeof(unsigned int));
}

/*
 * File trailer for SP_V1.c
 *
 * [EOF]
 */
