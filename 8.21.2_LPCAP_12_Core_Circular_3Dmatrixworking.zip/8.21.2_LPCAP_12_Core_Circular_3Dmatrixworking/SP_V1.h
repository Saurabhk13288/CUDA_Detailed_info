/*
 * File: SP_V1.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

#ifndef SP_V1_H
#define SP_V1_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void SP_V1(const int idata[8192], const int qdata[8192], unsigned int np,
                  unsigned int fsz, unsigned int RCout_data[],
                  int RCout_size[1], unsigned int DCout_data[],
                  int DCout_size[1], unsigned int *Dcnt,
                  unsigned int Ridx_data[], int Ridx_size[1],
                  unsigned int Peak_aRC[40], unsigned int Peak_aDP[40],
                  unsigned int Peak_RC[20], unsigned int Peak_DP[20],
                  int CFARdB[20], unsigned int Zero_DP[20], int SNR_Out[20]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for SP_V1.h
 *
 * [EOF]
 */
