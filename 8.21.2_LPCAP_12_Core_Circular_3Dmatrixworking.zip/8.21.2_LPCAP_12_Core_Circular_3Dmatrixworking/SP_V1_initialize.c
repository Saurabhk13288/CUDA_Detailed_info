/*
 * File: SP_V1_initialize.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "SP_V1_initialize.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void SP_V1_initialize(void)
{
}

/*
 * File trailer for SP_V1_initialize.c
 *
 * [EOF]
 */
