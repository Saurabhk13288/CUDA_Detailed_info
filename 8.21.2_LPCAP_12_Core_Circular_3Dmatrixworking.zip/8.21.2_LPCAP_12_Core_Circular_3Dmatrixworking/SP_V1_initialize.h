/*
 * File: SP_V1_initialize.h
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

#ifndef SP_V1_INITIALIZE_H
#define SP_V1_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void SP_V1_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for SP_V1_initialize.h
 *
 * [EOF]
 */
