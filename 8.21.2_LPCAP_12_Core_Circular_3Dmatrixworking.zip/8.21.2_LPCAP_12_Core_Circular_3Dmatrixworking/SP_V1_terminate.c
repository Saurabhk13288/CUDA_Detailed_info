/*
 * File: SP_V1_terminate.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "SP_V1_terminate.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void SP_V1_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for SP_V1_terminate.c
 *
 * [EOF]
 */
