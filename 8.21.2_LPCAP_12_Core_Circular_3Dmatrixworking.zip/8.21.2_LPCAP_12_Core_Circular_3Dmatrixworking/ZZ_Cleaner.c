#include <stdio.h>
#include <stdlib.h>
#include <sys/msg.h>

#define MSG_KEY                         0x1470          
#define no_queues                       20

int msqid_child[no_queues];          //IDs for the 8 queues

int main(){
    int i;
    for (i = 0; i < no_queues; i++){
        // Create or get 8 message queues using a loop
        msqid_child[i] = msgget(MSG_KEY + i , IPC_CREAT | 0666); // Dynamic key based on MSG_KEY_MAIN
        if (msqid_child[i] == -1) {
            perror("msgget Error (Queue 1-8)");
            exit(1);
        }

        if (msgctl(msqid_child[i], IPC_RMID, NULL) == -1) {
            perror("msgctl (IPC_RMID) failed");
            exit(EXIT_FAILURE);
        } else {
            printf("Message queue (ID: %d) successfully deleted.\n", msqid_child[i]);
        }
    }   
    return 0;
}
