/*
 * File: fft.c
 *
 * MATLAB Coder version            : 5.2
 * C/C++ source code generated on  : 15-Jul-2025 16:17:57
 */

/* Include Files */
#include "fft.h"
#include "FFTImplementationCallback.h"
#include "SP_V1_emxutil.h"
#include "SP_V1_types.h"
#include <math.h>

/* Function Definitions */
/*
 * Arguments    : double varargin_1
 *                emxArray_creal_T *y
 * Return Type  : void
 */
void fft(double varargin_1, emxArray_creal_T *y)
{
  static const creal_T x[128] = {{
                                     -0.999908447265625, /* re */
                                     0.0128173828125     /* im */
                                 },
                                 {
                                     0.659149169921875, /* re */
                                     -0.75201416015625  /* im */
                                 },
                                 {
                                     0.272064208984375, /* re */
                                     0.9622802734375    /* im */
                                 },
                                 {
                                     -0.989776611328125, /* re */
                                     -0.14263916015625   /* im */
                                 },
                                 {
                                     0.393951416015625, /* re */
                                     -0.91912841796875  /* im */
                                 },
                                 {
                                     0.872833251953125, /* re */
                                     0.488006591796875  /* im */
                                 },
                                 {
                                     -0.441925048828125, /* re */
                                     0.89703369140625    /* im */
                                 },
                                 {
                                     -0.969207763671875, /* re */
                                     -0.24627685546875   /* im */
                                 },
                                 {
                                     -0.116729736328125, /* re */
                                     -0.9931640625       /* im */
                                 },
                                 {
                                     0.80224609375,    /* re */
                                     -0.59698486328125 /* im */
                                 },
                                 {
                                     0.96856689453125, /* re */
                                     0.248779296875    /* im */
                                 },
                                 {
                                     0.55230712890625, /* re */
                                     0.833648681640625 /* im */
                                 },
                                 {
                                     0.007781982421875, /* re */
                                     0.999969482421875  /* im */
                                 },
                                 {
                                     -0.40106201171875, /* re */
                                     0.916046142578125  /* im */
                                 },
                                 {
                                     -0.6258544921875, /* re */
                                     0.779937744140625 /* im */
                                 },
                                 {
                                     -0.705322265625,  /* re */
                                     0.708892822265625 /* im */
                                 },
                                 {
                                     -0.6688232421875, /* re */
                                     0.743438720703125 /* im */
                                 },
                                 {
                                     -0.5015869140625, /* re */
                                     0.8651123046875   /* im */
                                 },
                                 {
                                     -0.160675048828125, /* re */
                                     0.98699951171875    /* im */
                                 },
                                 {
                                     0.35186767578125, /* re */
                                     0.93603515625     /* im */
                                 },
                                 {
                                     0.861114501953125, /* re */
                                     0.5084228515625    /* im */
                                 },
                                 {
                                     0.954925537109375, /* re */
                                     -0.296875          /* im */
                                 },
                                 {
                                     0.274139404296875, /* re */
                                     -0.961700439453125 /* im */
                                 },
                                 {
                                     -0.764892578125, /* re */
                                     -0.6441650390625 /* im */
                                 },
                                 {
                                     -0.822174072265625, /* re */
                                     0.5692138671875     /* im */
                                 },
                                 {
                                     0.476898193359375, /* re */
                                     0.878936767578125  /* im */
                                 },
                                 {
                                     0.85479736328125,  /* re */
                                     -0.518951416015625 /* im */
                                 },
                                 {
                                     -0.682373046875,   /* re */
                                     -0.730987548828125 /* im */
                                 },
                                 {
                                     -0.44171142578125, /* re */
                                     0.89715576171875   /* im */
                                 },
                                 {
                                     0.99810791015625,  /* re */
                                     -0.061676025390625 /* im */
                                 },
                                 {
                                     -0.67266845703125, /* re */
                                     -0.739959716796875 /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     1.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 },
                                 {
                                     0.0, /* re */
                                     0.0  /* im */
                                 }};
  emxArray_creal_T *b_fv;
  emxArray_creal_T *fv;
  emxArray_creal_T *wwc;
  emxArray_creal_T *yCol;
  emxArray_real_T *costab;
  emxArray_real_T *sintab;
  emxArray_real_T *sintabinv;
  double nt_im;
  double nt_re;
  double twid_im;
  double twid_re;
  int i;
  int ihi;
  int istart;
  int j;
  int k;
  int nInt2;
  int nInt2m1;
  int nRowsD2;
  int nfft_tmp_tmp;
  int nt_re_tmp;
  int rt;
  boolean_T useRadix2;
  nfft_tmp_tmp = (int)varargin_1;
  if (0 == (int)varargin_1) {
    j = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)varargin_1;
    emxEnsureCapacity_creal_T(y, j);
    for (j = 0; j < nfft_tmp_tmp; j++) {
      y->data[j].re = 0.0;
      y->data[j].im = 0.0;
    }
  } else {
    emxInit_real_T(&costab, 2);
    emxInit_real_T(&sintab, 2);
    emxInit_real_T(&sintabinv, 2);
    useRadix2 = (((int)varargin_1 > 0) &&
                 (((int)varargin_1 & ((int)varargin_1 - 1)) == 0));
    c_FFTImplementationCallback_get((int)varargin_1, useRadix2, &istart,
                                    &nInt2m1);
    c_FFTImplementationCallback_gen(nInt2m1, useRadix2, costab, sintab,
                                    sintabinv);
    emxInit_creal_T(&yCol, 1);
    if (useRadix2) {
      j = yCol->size[0];
      yCol->size[0] = (int)varargin_1;
      emxEnsureCapacity_creal_T(yCol, j);
      if ((int)varargin_1 > 128) {
        j = yCol->size[0];
        yCol->size[0] = (int)varargin_1;
        emxEnsureCapacity_creal_T(yCol, j);
        for (j = 0; j < nfft_tmp_tmp; j++) {
          yCol->data[j].re = 0.0;
          yCol->data[j].im = 0.0;
        }
      }
      if (128 < (int)varargin_1) {
        j = 126;
      } else {
        j = (int)varargin_1 - 2;
      }
      rt = (int)varargin_1 - 2;
      nRowsD2 = (int)varargin_1 / 2;
      k = nRowsD2 / 2;
      nInt2m1 = 0;
      nInt2 = 0;
      for (i = 0; i <= j; i++) {
        yCol->data[nInt2m1] = x[i];
        nInt2m1 = (int)varargin_1;
        useRadix2 = true;
        while (useRadix2) {
          nInt2m1 >>= 1;
          nInt2 ^= nInt2m1;
          useRadix2 = ((nInt2 & nInt2m1) == 0);
        }
        nInt2m1 = nInt2;
      }
      yCol->data[nInt2m1] = x[j + 1];
      if ((int)varargin_1 > 1) {
        for (i = 0; i <= rt; i += 2) {
          nt_re = yCol->data[i + 1].re;
          nt_im = yCol->data[i + 1].im;
          twid_im = yCol->data[i].re;
          twid_re = yCol->data[i].im;
          yCol->data[i + 1].re = yCol->data[i].re - yCol->data[i + 1].re;
          yCol->data[i + 1].im = yCol->data[i].im - yCol->data[i + 1].im;
          twid_im += nt_re;
          twid_re += nt_im;
          yCol->data[i].re = twid_im;
          yCol->data[i].im = twid_re;
        }
      }
      nInt2m1 = 2;
      rt = 4;
      nInt2 = ((k - 1) << 2) + 1;
      while (k > 0) {
        for (i = 0; i < nInt2; i += rt) {
          nt_re_tmp = i + nInt2m1;
          nt_re = yCol->data[nt_re_tmp].re;
          nt_im = yCol->data[nt_re_tmp].im;
          yCol->data[nt_re_tmp].re = yCol->data[i].re - nt_re;
          yCol->data[nt_re_tmp].im = yCol->data[i].im - nt_im;
          yCol->data[i].re += nt_re;
          yCol->data[i].im += nt_im;
        }
        istart = 1;
        for (j = k; j < nRowsD2; j += k) {
          twid_re = costab->data[j];
          twid_im = sintab->data[j];
          i = istart;
          ihi = istart + nInt2;
          while (i < ihi) {
            nt_re_tmp = i + nInt2m1;
            nt_re = twid_re * yCol->data[nt_re_tmp].re -
                    twid_im * yCol->data[nt_re_tmp].im;
            nt_im = twid_re * yCol->data[nt_re_tmp].im +
                    twid_im * yCol->data[nt_re_tmp].re;
            yCol->data[nt_re_tmp].re = yCol->data[i].re - nt_re;
            yCol->data[nt_re_tmp].im = yCol->data[i].im - nt_im;
            yCol->data[i].re += nt_re;
            yCol->data[i].im += nt_im;
            i += rt;
          }
          istart++;
        }
        k /= 2;
        nInt2m1 = rt;
        rt += rt;
        nInt2 -= nInt2m1;
      }
    } else {
      emxInit_creal_T(&wwc, 1);
      nInt2m1 = ((int)varargin_1 + (int)varargin_1) - 1;
      j = wwc->size[0];
      wwc->size[0] = nInt2m1;
      emxEnsureCapacity_creal_T(wwc, j);
      rt = 0;
      wwc->data[(int)varargin_1 - 1].re = 1.0;
      wwc->data[(int)varargin_1 - 1].im = 0.0;
      nInt2 = (int)varargin_1 << 1;
      for (k = 0; k <= nfft_tmp_tmp - 2; k++) {
        j = ((k + 1) << 1) - 1;
        if (nInt2 - rt <= j) {
          rt += j - nInt2;
        } else {
          rt += j;
        }
        nt_im = -3.1415926535897931 * (double)rt / (double)(int)varargin_1;
        if (nt_im == 0.0) {
          nt_re = 1.0;
          nt_im = 0.0;
        } else {
          nt_re = cos(nt_im);
          nt_im = sin(nt_im);
        }
        j = ((int)varargin_1 - k) - 2;
        wwc->data[j].re = nt_re;
        wwc->data[j].im = -nt_im;
      }
      j = nInt2m1 - 1;
      for (k = j; k >= nfft_tmp_tmp; k--) {
        wwc->data[k] = wwc->data[(nInt2m1 - k) - 1];
      }
      j = yCol->size[0];
      yCol->size[0] = (int)varargin_1;
      emxEnsureCapacity_creal_T(yCol, j);
      if ((int)varargin_1 > 128) {
        j = yCol->size[0];
        yCol->size[0] = (int)varargin_1;
        emxEnsureCapacity_creal_T(yCol, j);
        for (j = 0; j < nfft_tmp_tmp; j++) {
          yCol->data[j].re = 0.0;
          yCol->data[j].im = 0.0;
        }
      }
      if ((int)varargin_1 < 128) {
        nInt2m1 = (int)varargin_1 - 1;
      } else {
        nInt2m1 = 127;
      }
      for (k = 0; k <= nInt2m1; k++) {
        nt_re_tmp = ((int)varargin_1 + k) - 1;
        nt_re = wwc->data[nt_re_tmp].re;
        nt_im = wwc->data[nt_re_tmp].im;
        twid_re = x[k].re;
        twid_im = x[k].im;
        yCol->data[k].re = nt_re * twid_re + nt_im * twid_im;
        yCol->data[k].im = nt_re * twid_im - nt_im * twid_re;
      }
      j = nInt2m1 + 2;
      for (k = j; k <= nfft_tmp_tmp; k++) {
        yCol->data[k - 1].re = 0.0;
        yCol->data[k - 1].im = 0.0;
      }
      emxInit_creal_T(&fv, 1);
      emxInit_creal_T(&b_fv, 1);
      c_FFTImplementationCallback_r2b(yCol, istart, costab, sintab, fv);
      c_FFTImplementationCallback_r2b(wwc, istart, costab, sintab, b_fv);
      j = b_fv->size[0];
      b_fv->size[0] = fv->size[0];
      emxEnsureCapacity_creal_T(b_fv, j);
      nInt2m1 = fv->size[0];
      for (j = 0; j < nInt2m1; j++) {
        twid_re = fv->data[j].re * b_fv->data[j].im +
                  fv->data[j].im * b_fv->data[j].re;
        b_fv->data[j].re = fv->data[j].re * b_fv->data[j].re -
                           fv->data[j].im * b_fv->data[j].im;
        b_fv->data[j].im = twid_re;
      }
      c_FFTImplementationCallback_r2b(b_fv, istart, costab, sintabinv, fv);
      emxFree_creal_T(&b_fv);
      if (fv->size[0] > 1) {
        twid_re = 1.0 / (double)fv->size[0];
        nInt2m1 = fv->size[0];
        for (j = 0; j < nInt2m1; j++) {
          fv->data[j].re *= twid_re;
          fv->data[j].im *= twid_re;
        }
      }
      j = wwc->size[0];
      for (k = nfft_tmp_tmp; k <= j; k++) {
        nInt2m1 = k - (int)varargin_1;
        yCol->data[nInt2m1].re = wwc->data[k - 1].re * fv->data[k - 1].re +
                                 wwc->data[k - 1].im * fv->data[k - 1].im;
        yCol->data[nInt2m1].im = wwc->data[k - 1].re * fv->data[k - 1].im -
                                 wwc->data[k - 1].im * fv->data[k - 1].re;
      }
      emxFree_creal_T(&fv);
      emxFree_creal_T(&wwc);
    }
    emxFree_real_T(&sintabinv);
    emxFree_real_T(&sintab);
    emxFree_real_T(&costab);
    j = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = (int)varargin_1;
    emxEnsureCapacity_creal_T(y, j);
    for (j = 0; j < nfft_tmp_tmp; j++) {
      y->data[j] = yCol->data[j];
    }
    emxFree_creal_T(&yCol);
  }
}

/*
 * File trailer for fft.c
 *
 * [EOF]
 */
