/**
 * UDP Packet Sniffer using libpcap
 * Captures packets on a network interface and prints their size and timestamp.
 */

#include "A00_parameters.h"

int msgq_id[no_queues];
// struct  msgq_char       msgq_struct;

struct  msgq_4224_64    msgq_4224_64_sv;


int main(){
    change_msq_size();                              //A03_msgq_size.c To Change the default message queue size

    for (int i = 0 ; i < no_queues ; i++) {
        msgq_id[i] = q_creator(i);                  //function defined in A03_msgq_size.c
    }

    process_creator();                              //A04_fork.c //To create all the child process
    // while(1);

    return 0;
}
