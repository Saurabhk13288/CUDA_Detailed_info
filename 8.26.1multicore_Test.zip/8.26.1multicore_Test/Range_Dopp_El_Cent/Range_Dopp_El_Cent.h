//
// File: Range_Dopp_El_Cent.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:08:42
//

#ifndef RANGE_DOPP_EL_CENT_H
#define RANGE_DOPP_EL_CENT_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void
Range_Dopp_El_Cent(const double cpu_Rep[12000], const double cpu_Amp[65536],
                   const unsigned char Det[65536], const double CFARest[65536],
                   double CFARhigh, const double BP[8], double Tilt,
                   const unsigned char SLBBlank[4000], unsigned int *Tgt_Count,
                   double *cpu_RBm, double *cpu_DBm, double *cpu_Beamnom,
                   double *PK, double *CentRB, double *CentDB, double *CentEl,
                   double *Score, double *RangeExt, double *DoppExt,
                   double *BeamExt);

#endif
//
// File trailer for Range_Dopp_El_Cent.h
//
// [EOF]
//
