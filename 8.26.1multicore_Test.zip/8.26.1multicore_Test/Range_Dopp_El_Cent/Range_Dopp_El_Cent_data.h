//
// File: Range_Dopp_El_Cent_data.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:08:42
//

#ifndef RANGE_DOPP_EL_CENT_DATA_H
#define RANGE_DOPP_EL_CENT_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Variable Declarations
extern bool isInitialized_Range_Dopp_El_Cent;

#endif
//
// File trailer for Range_Dopp_El_Cent_data.h
//
// [EOF]
//
