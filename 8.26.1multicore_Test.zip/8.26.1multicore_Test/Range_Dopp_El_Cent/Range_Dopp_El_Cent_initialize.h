//
// File: Range_Dopp_El_Cent_initialize.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:08:42
//

#ifndef RANGE_DOPP_EL_CENT_INITIALIZE_H
#define RANGE_DOPP_EL_CENT_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void Range_Dopp_El_Cent_initialize();

#endif
//
// File trailer for Range_Dopp_El_Cent_initialize.h
//
// [EOF]
//
