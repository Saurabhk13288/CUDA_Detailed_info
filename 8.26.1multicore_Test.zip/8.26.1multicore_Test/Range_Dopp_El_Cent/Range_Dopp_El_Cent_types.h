//
// File: Range_Dopp_El_Cent_types.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:08:42
//

#ifndef RANGE_DOPP_EL_CENT_TYPES_H
#define RANGE_DOPP_EL_CENT_TYPES_H

// Include Files
#include "rtwtypes.h"

#endif
//
// File trailer for Range_Dopp_El_Cent_types.h
//
// [EOF]
//
