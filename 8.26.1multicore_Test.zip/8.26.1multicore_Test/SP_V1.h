//
// File: SP_V1.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:06:47
//

#ifndef SP_V1_H
#define SP_V1_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void SP_V1(const int cpu_idata[8192], const int cpu_qdata[8192],
                  unsigned int np, unsigned int fsz, double cpu_DPout[8192],
                  double cpu_CFAR_est[8192], unsigned char cpu_tgt_est[8192],
                  unsigned int *det_count, double cpu_report[1500]);

#endif
//
// File trailer for SP_V1.h
//
// [EOF]
//
