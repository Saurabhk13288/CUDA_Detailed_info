//
// File: SP_V1_initialize.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:06:47
//

#ifndef SP_V1_INITIALIZE_H
#define SP_V1_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void SP_V1_initialize();

#endif
//
// File trailer for SP_V1_initialize.h
//
// [EOF]
//
