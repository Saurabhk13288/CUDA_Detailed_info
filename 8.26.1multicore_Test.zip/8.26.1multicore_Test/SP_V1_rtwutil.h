//
// File: SP_V1_rtwutil.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:06:47
//

#ifndef SP_V1_RTWUTIL_H
#define SP_V1_RTWUTIL_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void checkCudaError(cudaError_t errorCode, const char *file, int b_line);

extern void gpuThrowError(unsigned int errorCode, const char *errorName,
                          const char *errorString, const char *file,
                          int b_line);

#endif
//
// File trailer for SP_V1_rtwutil.h
//
// [EOF]
//
