//
// File: SP_V1_terminate.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:06:47
//

#ifndef SP_V1_TERMINATE_H
#define SP_V1_TERMINATE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void SP_V1_terminate();

#endif
//
// File trailer for SP_V1_terminate.h
//
// [EOF]
//
