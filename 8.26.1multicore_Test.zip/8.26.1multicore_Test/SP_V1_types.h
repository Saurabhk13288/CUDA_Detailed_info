//
// File: SP_V1_types.h
//
// GPU Coder version                    : 25.1
// CUDA/C/C++ source code generated on  : 22-Aug-2025 19:06:47
//

#ifndef SP_V1_TYPES_H
#define SP_V1_TYPES_H

// Include Files
#include "rtwtypes.h"

// Type Definitions
struct emxArray_creal_T {
  creal_T *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  bool canFreeData;
};

struct emxArray_real_T {
  double *data;
  int *size;
  int allocatedSize;
  int numDimensions;
  bool canFreeData;
};

#endif
//
// File trailer for SP_V1_types.h
//
// [EOF]
//
