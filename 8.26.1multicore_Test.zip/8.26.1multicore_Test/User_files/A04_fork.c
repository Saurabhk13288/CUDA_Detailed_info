/*  This main program can be used to create child process
    Total proccess created is given by the formula 2^N
    Total child proccess created is given by the formula 2^N-1
    N is the number of times the fork command is used.
    
    Fork has been used 4 times in this process, 
    so a total of 16 process are created.
    15 child are created, and 1 is the main process already running.
    n1, n2, n3, n4 are used as binary counters (for understanding)

    0000 - Child 1
    0001 - Child 2
    |   |   |   |
    |   |   |   |   
    1110 - Child 15
    ===============
    1111 - Main process

    Note: Child are not created in this order
    For understanding, we are using this numbering,
    Actual hierarchy is different and is not currently required. (^_^)
*/
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "A02_cpu_affinity.h"

int n1, n2, n3, n4;
int slptime = 0;
int intital_core = 0;
extern FILE *NEWTESTPOINTER;

void printID(){
        // printf("%d %d %d %d\n",n1, n2, n3, n4);
        // printf("ParentID: %d\tMyId: %d\n", getppid(), getpid());
        // printf("MyId: %d\n", getpid());
}

int checkPID(){
    bool new1 = n1;
    bool new2 = n2;
    bool new3 = n3;
    bool new4 = n4;

    return new1 * 8 + new2 * 4 + new3 * 2 + new4 * 1;
}

void process_creator(){
    n1 = fork();
    n2 = fork();
    n3 = fork();
    n4 = fork();
    
    if (checkPID() == 1){
        // sleep (slptime + 1);
        printID();
        set_core(intital_core + 2);                                 //A02_cpu_affinity.c
        checkPID();
        //while(1);
        main_SP_V1();
    }

    // else if (checkPID() == 2){
    //     // sleep (slptime + 2);
    //     printID();
    //     set_core(intital_core + 3);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    // }

    // else if (checkPID() == 3){
    //     // sleep (slptime + 3);
    //     printID();
    //     set_core(intital_core + 4);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    // }

    // else if (checkPID() == 4){
    //     // sleep (slptime + 4);
    //     printID();
    //     set_core(intital_core + 5);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    // }

    // else if (checkPID() == 5){
    //     // sleep (slptime + 5);
    //     printID();
    //     set_core(intital_core + 6);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    // }

    // else if (checkPID() == 6){
    //     // sleep (slptime + 6);
    //     printID();
    //     set_core(intital_core + 7);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    // }

    // else if (checkPID() == 7){
    //     // sleep (slptime + 7);
    //     printID();
    //     set_core(intital_core + 8);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();    
    // }

    // else if (checkPID() == 8){
    //     // sleep (slptime + 8);
    //     printID();
    //     set_core(intital_core + 9);
    //     checkPID();
    //     //while(1);
    //     main_SP_V1();
    //     //q_creator(8);
    // }

    
    // else if (checkPID() == 9){
    //     //sleep (slptime + 9);
    //     printID();
    //     set_core(intital_core + 10);
    //     checkPID();
    //     //while(1);
    //     sleep(4);
    //     msgq_collector();
    // }
    // else if (checkPID() == 10){
    //     // sleep (slptime + 10);
    //     printID();
    //     set_core(intital_core + 1);
    //     checkPID();
    //     sleep(2);
    //     // file_write();
    //     // while(1);
    //     queue_extractor();                              //A06_msgq_rece.c
    // }
    // else if (checkPID() == 15){
    //     // sleep (slptime + 11);
    //     printID();
    //     set_core(intital_core + 0);
    //     checkPID();
    //     // sleep(4);
    //     // file_write();

    //     // const char *newpath = get_file_path("DATA_FILE", "QI_8192_DATA", "00_data_QI", "bin");
    //     // if(newpath == NULL){
    //     //     exit(1);
    //     // }
    //     // NEWTESTPOINTER = fopen(newpath,"wb");
    //     // if(NEWTESTPOINTER == NULL){
    //     //     printf("RECE: file not open data_Q.bin\n");
    //     // }

    //     setup_signal_handlers();                        //A01_cleanup.c Register signals
    //     //while(1);
    //     sleep(5);
    //     A_lpcap();                                      //A05_lpcap.c
    // }
    //Add more conditions for creating more child process.
}