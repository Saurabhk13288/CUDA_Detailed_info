#include <stdio.h>
#include <stdlib.h>
#include "iq.h"  // Presumably this header contains necessary data.

int main(int argc, char **argv) {

    unsigned char buff[65536];

    // Open binary file for writing
    FILE *fp = fopen("file.bin", "wb");
    if (fp == NULL) {
        printf("Failed to open file for writing\n");
        return EXIT_FAILURE;
    }

    // Open the source file for reading (assuming iq.h is a file with binary data)
    FILE *source_fp = fopen("iq.h", "rb");
    if (source_fp == NULL) {
        printf("Failed to open iq.h for reading\n");
        fclose(fp);  // Ensure to close the file before returning
        return EXIT_FAILURE;
    }

    // Read and write in chunks of the buffer size
    size_t bytes_read;
    while ((bytes_read = fread(buff, 1, sizeof(buff), source_fp)) > 0) {
        size_t bytes_written = fwrite(buff, 1, bytes_read, fp);
        if (bytes_written != bytes_read) {
            fprintf(stderr, "fwrite() failed. Expected %zu bytes, but wrote %zu bytes\n", bytes_read, bytes_written);
            fclose(fp);
            fclose(source_fp);
            return EXIT_FAILURE;
        }
        printf("Written %zu bytes to file\n", bytes_written);
    }

    // Close the files
    fclose(fp);
    fclose(source_fp);

    return 0;
}
